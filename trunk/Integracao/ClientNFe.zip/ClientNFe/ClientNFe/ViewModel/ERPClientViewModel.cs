﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClientNFe.View
{
    public class ERPClientViewModel
    {
        public string title { get ;  private set; }

        public ERPClientViewModel()
        {
            this.title = "Projeto T2Ti ERP";
        }
    }
}
