﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Collections.ObjectModel;
using ClientNFe.NFeServiceReference;
using SearchWindow;
using ClientNFe.Model;
using uninfe;
using UniNFeLibrary;
using UniNFeLibrary.Enums;
using System.Threading;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using System.Globalization;
using ClientNFe.Util;
using System.Diagnostics;

namespace ClientNFe.View.NFe
{
    public class NFeViewModel : ERPViewModelBase
    {
        public Boolean isSelectedTabLista { get; set; }
        public Boolean isSelectedTabDados { get; set; }
        public ContentPresenter contentPresenterTabDados { get; set; }
        public ObservableCollection<NFeCabecalhoDTO> listaNFe { get; set; }
        public NFeCabecalhoDTO nfeSelected { get; set; }
        public ProdutoDTO produtoSelected { get; set; }
        private EmpresaDTO empresa { get; set; }
        private Dictionary<ServicoUniNFe, Servicos> servicosUniNfe;
        private Dictionary<Thread, ParametroThread> threads;
        public TRetEnviNFe retEnviNFe { get; set; }
        public TRetConsReciNFe retConsReci { get; set; }
        public NFeDetalheDTO detalheNFe { get; set; }

        public NFeViewModel()
        {
            try
            {
                contentPresenterTabDados = new ContentPresenter();
                listaNFe = new ObservableCollection<NFeCabecalhoDTO>();

                using (NFeClient serv = new NFeClient())
                {
                    empresa = serv.selectEmpresaId(1);
                }

                Empresa.CarregaConfiguracao();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void desativarServicosNFE()
        {
            foreach (KeyValuePair<Thread, int> t in Auxiliar.threads)
            {
                try
                {
                    Thread thread = t.Key;

                    thread.Abort();

                }
                catch (Exception ex)
                {
                }
            }
        }

        public bool montarNFe()
        {
            try
            {
                string FORMATO_DATA = "yyyy-MM-dd";

                //EnviNFe
                //TEnviNFe enviNFe = new TEnviNFe();
                //enviNFe.versao = "2.00";
                //enviNFe.idLote = DateTime.Now.ToString("yyyyMMddHHmmss");
                //enviNFe.NFe = new TNFe[1];

                //NFe
                TNFe nfe = new TNFe();
                //enviNFe.NFe[0] = nfe;

                //Informacoes NFe
                TNFeInfNFe infNFe = new TNFeInfNFe();
                infNFe.Id = "NFe" + nfeSelected.chaveAcesso + nfeSelected.digitoChaveAcesso;
                infNFe.versao = "2.00";
                nfe.infNFe = infNFe;

                //Ide
                TNFeInfNFeIde infNFeIde = new TNFeInfNFeIde();
                infNFeIde.cNF = nfeSelected.codigoNumerico;
                infNFeIde.natOp = nfeSelected.naturezaOperacao;
                infNFeIde.indPag = (TNFeInfNFeIdeIndPag) int.Parse(nfeSelected.indicadorFormaPagamento);
                infNFeIde.mod = (TMod) Enum.Parse(typeof(TMod), "Item"+(nfeSelected.codigoModelo));
                infNFeIde.serie = nfeSelected.serie;
                infNFeIde.nNF = int.Parse( nfeSelected.numero).ToString();
                infNFeIde.dEmi =((DateTime) nfeSelected.dataEmissao).ToString(FORMATO_DATA);
                infNFeIde.dSaiEnt = ((DateTime)nfeSelected.dataEntradaSaida).ToString(FORMATO_DATA);
                infNFeIde.tpEmis = (TNFeInfNFeIdeTpEmis)Enum.Parse(typeof(TNFeInfNFeIdeTpEmis), "Item" + nfeSelected.tipoEmissao);
                infNFeIde.verProc = ((int)nfeSelected.versaoProcessoEmissao).ToString();
                infNFeIde.cUF = (TCodUfIBGE)Enum.Parse(typeof(TCodUfIBGE),"Item"+ empresa.codigoIBGE_UF);
                infNFeIde.cMunFG = empresa.endereco.municipioIbge.ToString();
                infNFeIde.finNFe = (TFinNFe)Enum.Parse(typeof(TFinNFe), "Item" + nfeSelected.finalidadeEmissao);
                infNFeIde.tpNF = (TNFeInfNFeIdeTpNF)Enum.Parse(typeof(TNFeInfNFeIdeTpNF), "Item" + nfeSelected.tipoEmissao);
                infNFeIde.cDV = nfeSelected.digitoChaveAcesso;
                infNFeIde.tpImp = (TNFeInfNFeIdeTpImp)Enum.Parse(typeof(TNFeInfNFeIdeTpImp), "Item" + nfeSelected.formatoImpressaoDANFE);
                infNFeIde.procEmi = TProcEmi.Item0;
                infNFeIde.tpAmb = (TAmb)Enum.Parse(typeof(TAmb), "Item" + nfeSelected.ambiente);
                nfe.infNFe.ide = infNFeIde;

                //Endereco Emitente
                TEnderEmi enderEmit = new TEnderEmi();
                enderEmit.xLgr = empresa.endereco.logradouro;
                enderEmit.nro = empresa.endereco.numero;
                if(!string.IsNullOrEmpty(empresa.endereco.complemento))
                    enderEmit.xCpl = empresa.endereco.complemento;
                enderEmit.xBairro = empresa.endereco.bairro;
                enderEmit.cMun = empresa.endereco.municipioIbge.ToString();
                enderEmit.xMun = nfeSelected.emitente.nomeMunicipio;
                enderEmit.UF = (TUfEmi)Enum.Parse(typeof(TUfEmi), empresa.endereco.uf);
                enderEmit.CEP = nfeSelected.emitente.cep;
                enderEmit.cPais = (TEnderEmiCPais)Enum.Parse(typeof(TEnderEmiCPais), "Item" + nfeSelected.emitente.codigoPais);
                enderEmit.xPais = (TEnderEmiXPais)Enum.Parse(typeof(TEnderEmiXPais), nfeSelected.emitente.nomePais);
                enderEmit.fone = nfeSelected.emitente.telefone;

                //Emitente
                TNFeInfNFeEmit emit = new TNFeInfNFeEmit();
                emit.CRT = (TNFeInfNFeEmitCRT) Enum.Parse(typeof(TNFeInfNFeEmitCRT), "Item" + empresa.crt);
                emit.IE = empresa.inscricaoEstadual;
                emit.xNome = empresa.razaoSocial;
                emit.xFant = empresa.nomeFantasia;
                emit.Item = empresa.cnpj;

                emit.enderEmit = enderEmit;
                nfe.infNFe.emit = emit;

                //Endereco destinatario
                TEndereco enderDest = new TEndereco();
                enderDest.xLgr = nfeSelected.destinatario.logradouro;
                enderDest.nro = nfeSelected.destinatario.numero;
                enderDest.xCpl = nfeSelected.destinatario.complemento;
                enderDest.xBairro = nfeSelected.destinatario.bairro;
                enderDest.cMun = nfeSelected.destinatario.codigoMunicipio.ToString();
                enderDest.xMun = nfeSelected.destinatario.nomeMunicipio;
                enderDest.UF = (TUf)Enum.Parse(typeof(TUf), nfeSelected.destinatario.uf);
                enderDest.CEP = nfeSelected.destinatario.cep;
                enderDest.cPais = (Tpais)  nfeSelected.destinatario.codigoPais;
                enderDest.xPais = nfeSelected.destinatario.nomePais;
                enderDest.fone = nfeSelected.destinatario.telefone;

                //Destinatario
                TNFeInfNFeDest dest = new TNFeInfNFeDest();
                //dest.xNome = nfeSelected.destinatario.razaoSocial;
                dest.xNome = "NF-E EMITIDA EM AMBIENTE DE HOMOLOGACAO - SEM VALOR FISCAL";
                dest.IE = nfeSelected.destinatario.ie;
                dest.Item = nfeSelected.destinatario.cpfCnpj;
                dest.ItemElementName = ItemChoiceType3.CPF;
                if (nfeSelected.destinatario.cpfCnpj.Length > 11)
                    dest.ItemElementName = ItemChoiceType3.CNPJ;
                nfe.infNFe.dest = dest;
                dest.enderDest = enderDest;

                //Informacoes Adicionais
                TNFeInfNFeInfAdic infAdic = new TNFeInfNFeInfAdic();
                infAdic.infAdFisco = nfeSelected.informacoesAddFisco;
                infAdic.infCpl = nfeSelected.informacoesComplementares;
                nfe.infNFe.infAdic = infAdic;

                //detalhes
                List<TNFeInfNFeDet> listaNFeDet = new List<TNFeInfNFeDet>();

                foreach (NFeDetalheDTO detalhe in nfeSelected.listaDetalhe)
                {
                    TNFeInfNFeDetProd prod = new TNFeInfNFeDetProd();
                    prod.cProd = detalhe.codigoProduto;
                    prod.cEAN = detalhe.gtin;
                    prod.cEANTrib = detalhe.gtinUnidadeTributavel;
                    prod.xProd = detalhe.nomeProduto;
                    prod.NCM = detalhe.ncm;
                    if(!string.IsNullOrEmpty(detalhe.exTIPI.ToString()))
                        prod.EXTIPI = detalhe.exTIPI.ToString();
                    prod.CFOP = (TCfop)Enum.Parse(typeof(TCfop), "Item" + detalhe.cfop);
                    prod.uCom = detalhe.unidadeComercial;
                    prod.qCom = formataValorNFe(detalhe.quantidadeComercial);
                    prod.vUnCom = formataValorNFe(detalhe.valorUnitarioComercial);
                    prod.vProd = formataValorNFe(detalhe.valorTotal);
                    prod.uTrib = detalhe.unidadeTributavel;
                    prod.qTrib = formataQtdNFe(detalhe.quantidadeTributavel);
                    prod.vUnTrib = formataValorNFe(detalhe.valorUnitarioTributacao);
                    prod.indTot = (TNFeInfNFeDetProdIndTot)1;
                    if(detalhe.valorFrete != null && detalhe.valorFrete > 0)
                        prod.vFrete = formataValorNFe(detalhe.valorFrete);
                    if (detalhe.valorSeguro != null && detalhe.valorSeguro > 0)
                        prod.vSeg = formataValorNFe(detalhe.valorSeguro);
                    if (detalhe.valorDesconto != null && detalhe.valorDesconto > 0)
                        prod.vDesc = formataValorNFe(detalhe.valorDesconto);

                    TNFeInfNFeDetImpostoICMSICMS00 icms00 = new TNFeInfNFeDetImpostoICMSICMS00();
                    icms00.CST = (TNFeInfNFeDetImpostoICMSICMS00CST)Enum.Parse(typeof(TNFeInfNFeDetImpostoICMSICMS00CST), "Item" + detalhe.cstICMS.Substring(0, 2));
                    icms00.orig = (Torig) int.Parse(detalhe.origemMercadoria);
                    icms00.modBC = (TNFeInfNFeDetImpostoICMSICMS00ModBC)int.Parse(detalhe.modalidadeBC_ICMS);
                    icms00.vBC = formataValorNFe(detalhe.baseCalculoICMS);
                    icms00.pICMS = formataValorNFe(detalhe.aliquotaICMS);
                    icms00.vICMS = formataValorNFe(detalhe.valorICMS);

                    TNFeInfNFeDetImpostoICMS icms = new TNFeInfNFeDetImpostoICMS();
                    icms.Item = icms00;

                    TNFeInfNFeDetImposto imp = new TNFeInfNFeDetImposto();
                    imp.Items = new object[] { icms };

                    TNFeInfNFeDetImpostoPISPISOutr pisOutr = new TNFeInfNFeDetImpostoPISPISOutr();
                    pisOutr.CST = (TNFeInfNFeDetImpostoPISPISOutrCST)Enum.Parse(typeof(TNFeInfNFeDetImpostoPISPISOutrCST), "Item" + detalhe.cstPIS);
                    pisOutr.vPIS = formataValorNFe(detalhe.valorPIS);
                    pisOutr.Items = new string[2];
                    pisOutr.Items[0] = formataValorNFe(detalhe.valorBaseCalculoPIS);
                    pisOutr.Items[1] = formataValorNFe(detalhe.valorPIS);
                    pisOutr.ItemsElementName = new ItemsChoiceType1[2];
                    pisOutr.ItemsElementName[0] = ItemsChoiceType1.vBC;
                    pisOutr.ItemsElementName[1] = ItemsChoiceType1.pPIS;

                    TNFeInfNFeDetImpostoPIS pis = new TNFeInfNFeDetImpostoPIS();
                    pis.Item = pisOutr;
                    imp.PIS = pis;

                    TNFeInfNFeDetImpostoCOFINSCOFINSOutr cofinsOutr = new TNFeInfNFeDetImpostoCOFINSCOFINSOutr();
                    cofinsOutr.CST = (TNFeInfNFeDetImpostoCOFINSCOFINSOutrCST)Enum.Parse(typeof(TNFeInfNFeDetImpostoCOFINSCOFINSOutrCST), "Item" + detalhe.cstCOFINS);
                    cofinsOutr.vCOFINS = formataValorNFe(detalhe.valorCOFINS);
                    cofinsOutr.Items = new string[2];
                    cofinsOutr.Items[0] = formataValorNFe(detalhe.baseCalculoCOFINS);
                    cofinsOutr.Items[1] = formataValorNFe(detalhe.valorCOFINS);
                    cofinsOutr.ItemsElementName = new ItemsChoiceType3[2];
                    cofinsOutr.ItemsElementName[0] = ItemsChoiceType3.vBC;
                    cofinsOutr.ItemsElementName[1] = ItemsChoiceType3.pCOFINS;


                    TNFeInfNFeDetImpostoCOFINS cofins = new TNFeInfNFeDetImpostoCOFINS();
                    cofins.Item = cofinsOutr;
                    imp.COFINS = cofins;

                    TNFeInfNFeDet nfeDet = new TNFeInfNFeDet();
                    nfeDet.imposto = imp;
                    nfeDet.prod = prod;
                    nfeDet.infAdProd = detalhe.informacoesAdicionais;
                    nfeDet.nItem = detalhe.numeroItem.ToString();

                    listaNFeDet.Add(nfeDet);
                }
                nfe.infNFe.det = listaNFeDet.ToArray();

                TNFeInfNFeTotalICMSTot icmsTot = new TNFeInfNFeTotalICMSTot();
                icmsTot.vBC = formataValorNFe(nfeSelected.baseCalculoICMS);
                icmsTot.vICMS = formataValorNFe(nfeSelected.valorICMS);
                icmsTot.vBCST = formataValorNFe(nfeSelected.baseCalculoICMS_ST);
                icmsTot.vST = formataValorNFe(nfeSelected.valorICMS_ST);
                icmsTot.vProd = formataValorNFe(nfeSelected.valorTotalProdutos);
                icmsTot.vFrete = formataValorNFe(nfeSelected.valorFrete);
                icmsTot.vSeg = formataValorNFe(nfeSelected.valorSeguro);
                icmsTot.vDesc = formataValorNFe(nfeSelected.valorDesconto);
                icmsTot.vDesc = formataValorNFe(nfeSelected.valorDesconto);
                icmsTot.vII = formataValorNFe(0);
                icmsTot.vIPI = formataValorNFe(nfeSelected.valorIPI);
                icmsTot.vPIS = formataValorNFe(nfeSelected.valorPIS);
                icmsTot.vCOFINS = formataValorNFe(nfeSelected.valorCOFINS);
                icmsTot.vOutro = formataValorNFe(nfeSelected.valorDespesasAcessorias);
                icmsTot.vNF = formataValorNFe(nfeSelected.valorTotal);

                TNFeInfNFeTotal total = new TNFeInfNFeTotal();
                total.ICMSTot = icmsTot;
                nfe.infNFe.total = total;

                TNFeInfNFeTranspTransporta transporta = new TNFeInfNFeTranspTransporta();
                TNFeInfNFeTransp transp = new TNFeInfNFeTransp();
                transp.transporta = transporta;
                transp.modFrete = TNFeInfNFeTranspModFrete.Item1;

                nfe.infNFe.transp = transp;

                MemoryStream memStream = new MemoryStream();
                XmlSerializer serializer = new XmlSerializer(typeof(TNFe));
                XmlSerializerNamespaces ns = new XmlSerializerNamespaces();

                ns.Add("", "http://www.portalfiscal.inf.br/nfe");
                serializer.Serialize(memStream, nfe, ns);
                memStream.Position = 0;
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(memStream);
                xmlDoc.Save(""+nfeSelected.chaveAcesso + nfeSelected.digitoChaveAcesso + "-nfe.xml");
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool receberMensagemProcLoteNFe()
        {
            try
            {
                bool resultado = false;
                retConsReci = null;
                string xmlNFeMsgLote = retEnviNFe.infRec.nRec + "-pro-rec.xml";
                bool arquivoExiste = false;
                int cont = 0;
                while (!arquivoExiste || cont > 120)
                {
                    arquivoExiste = File.Exists(Empresa.Configuracoes[0].PastaRetorno + "\\" + xmlNFeMsgLote);
                    if (arquivoExiste)
                    {
                        XmlSerializer serializer = new XmlSerializer(typeof(TRetConsReciNFe));
                        StreamReader sReader = new StreamReader(Empresa.Configuracoes[0].PastaRetorno + "\\" + xmlNFeMsgLote);
                        retConsReci = (TRetConsReciNFe)serializer.Deserialize(sReader);
                        if(retConsReci != null)
                            resultado = true;
                        sReader.Close();
                    }
                    else
                    {
                        cont++;
                        Thread.Sleep(1000);
                    }

                }
                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool receberMensagemNrLoteNFe(out string numLote)
        {
            try
            {
                bool resultado = false;
                string xmlNFeNumLote = nfeSelected.chaveAcesso + nfeSelected.digitoChaveAcesso + "-num-lot.xml";
                string nfeErro = nfeSelected.chaveAcesso + nfeSelected.digitoChaveAcesso + "-nfe.err";
                bool arquivoExiste = false;
                bool erroExiste = false;
                numLote = "";
                int cont = 0;
                while((!arquivoExiste && !erroExiste) || cont > 120)
                {
                    arquivoExiste = File.Exists(Empresa.Configuracoes[0].PastaRetorno + "\\" + xmlNFeNumLote);
                    erroExiste = File.Exists(Empresa.Configuracoes[0].PastaRetorno + "\\" + nfeErro);
                    if (arquivoExiste)
                    {
                        XmlTextReader reader = new XmlTextReader(Empresa.Configuracoes[0].PastaRetorno + "\\" + xmlNFeNumLote);
                        XmlDocument doc = new XmlDocument();
                        doc.Load(reader);
                        numLote = doc.SelectSingleNode("//NumeroLoteGerado").InnerText;
                        resultado = true;
                        reader.Close();
                    }else if(erroExiste)
                    {
                        numLote = File.ReadAllText(Empresa.Configuracoes[0].PastaRetorno + "\\" + nfeErro, Encoding.GetEncoding(28591));
                    }
                    else 
                    {
                        cont++;
                        Thread.Sleep(1000);
                    }

                }
                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool receberMensagemLoteNFe(int numLote)
        {
            try
            {
                bool resultado = false;
                retEnviNFe = null;
                string xmlNFeMsgLote = numLote.ToString("000000000000000") + "-rec.xml";
                bool arquivoExiste = false;
                int cont = 0;
                while (!arquivoExiste || cont > 120)
                {
                    arquivoExiste = File.Exists(Empresa.Configuracoes[0].PastaRetorno + "\\" + xmlNFeMsgLote);
                    if (arquivoExiste)
                    {
                        XmlSerializer serializer = new XmlSerializer(typeof(TRetEnviNFe));
                        StreamReader sReader = new StreamReader(Empresa.Configuracoes[0].PastaRetorno + "\\" + xmlNFeMsgLote);
                        retEnviNFe = (TRetEnviNFe)serializer.Deserialize(sReader);
                        if(retEnviNFe != null)
                            resultado = true;
                        sReader.Close();
                    }
                    else
                    {
                        cont++;
                        Thread.Sleep(1000);
                    }

                }
                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool enviarNFe()
        {
            try
            {
                bool resultado = false;
                string xmlNFeOrig = nfeSelected.chaveAcesso + nfeSelected.digitoChaveAcesso + "-nfe.xml";
                string xmlNFeDest = Empresa.Configuracoes[0].PastaEnvio + "\\" + nfeSelected.chaveAcesso + nfeSelected.digitoChaveAcesso + "-nfe.xml";

                if (File.Exists(xmlNFeOrig))
                {
                    File.Move(xmlNFeOrig, xmlNFeDest);
                    resultado = true;
                }
                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool excluirArquivos()
        {
            try
            {
                bool resultado = false;
                string diretorioErro = Empresa.Configuracoes[0].PastaErro;
                string diretorioRetorno = Empresa.Configuracoes[0].PastaRetorno;
                string[] arquivos = Directory.GetFiles(diretorioErro);
                foreach (string arquivo in arquivos)
                {
                    File.Delete(arquivo);
                }

                arquivos = Directory.GetFiles(diretorioRetorno);
                foreach (string arquivo in arquivos)
                {
                    File.Delete(arquivo);
                }
                resultado = true;

                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string formataValorNFe(decimal? valor)
        {
            try
            {
                if (valor == null)
                    valor = 0;

                return ((decimal)valor).ToString("0.00", CultureInfo.InvariantCulture);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        private string formataQtdNFe(decimal? quantidade)
        {
            try
            {
                if (quantidade == null)
                    quantidade = 0;

                return ((decimal)quantidade).ToString("0.0000", CultureInfo.InvariantCulture);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public void ativarServicosNFE()
        {
            try
            {
                servicosUniNfe = new Dictionary<ServicoUniNFe, Servicos>();
                threads = new Dictionary<Thread, ParametroThread>();

                ConfiguracaoApp.TipoAplicativo = TipoAplicativo.Nfe;
                ConfiguracaoApp.CarregarDados();
                ConfiguracaoApp.VersaoXMLCanc = "2.00";
                ConfiguracaoApp.VersaoXMLConsCad = "2.00";
                ConfiguracaoApp.VersaoXMLInut = "2.00";
                ConfiguracaoApp.VersaoXMLNFe = "2.00";
                ConfiguracaoApp.VersaoXMLPedRec = "2.00";
                ConfiguracaoApp.VersaoXMLPedSit = "2.00";
                ConfiguracaoApp.VersaoXMLStatusServico = "2.00";
                ConfiguracaoApp.VersaoXMLCabecMsg = "2.00";
                ConfiguracaoApp.VersaoXMLEnvDPEC = "1.01";
                ConfiguracaoApp.VersaoXMLConsDPEC = "1.01";
                ConfiguracaoApp.nsURI = "http://www.portalfiscal.inf.br/nfe";
                SchemaXML.CriarListaIDXML();

                Auxiliar.threads.Clear();
                threads.Clear();

                //Primeiro eu preparo as thread´s a serem executadas, atualizo a
                //lista de thread´s e a empresa que está sendo executada nela
                //para depois iniciá-las, ou gera erros nas pesquisas pela empresa da
                //thread. Wandrey 02/08/2010
                for (int i = 0; i < Empresa.Configuracoes.Count; i++)
                {
                    if (Empresa.Configuracoes[i].Certificado == string.Empty)
                        continue;

                    //Criar uma lista dos serviços a serem executados
                    servicosUniNfe.Clear();
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.EnviarLoteNfe);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.AssinarNFePastaEnvio);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.MontarLoteUmaNFe);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.PedidoSituacaoLoteNFe);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.PedidoConsultaSituacaoNFe);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.AssinarNFePastaEnvioEmLote);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.MontarLoteVariasNFe);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.ValidarAssinar);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.CancelarNFe);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.InutilizarNumerosNFe);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.PedidoConsultaStatusServicoNFe);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.ConsultaCadastroContribuinte);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.ConsultaInformacoesUniNFe);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.AlterarConfiguracoesUniNFe);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.GerarChaveNFe);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.EmProcessamento);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.ConverterTXTparaXML);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.EnviarDPEC);
                    servicosUniNfe.Add(new ServicoUniNFe(), Servicos.ConsultarDPEC);    //danasa 21/10/2010
                    if (Empresa.Configuracoes[i].DiasLimpeza != 0)  //danasa 27-2-2011
                        servicosUniNfe.Add(new ServicoUniNFe(), Servicos.LimpezaTemporario);

                    //Preparar as thread´s a serem executadas
                    foreach (KeyValuePair<ServicoUniNFe, Servicos> item in servicosUniNfe)
                    {
                        ServicoUniNFe servico = item.Key;
                        Thread t = new Thread(new ParameterizedThreadStart(servico.BuscaXML));
                        t.Name = (item.Value.ToString().Trim() + Empresa.Configuracoes[i].CNPJ.Trim()).ToUpper();

                        //Atualiza a coleção de thread´s e a empresa que será executada enal
                        Auxiliar.threads.Add(t, i);

                        //Atualizar a coleção das thread´s a serem executadas.
                        threads.Add(t, new ParametroThread(item.Value));
                    }
                }
                //Executar as thread´s de todas as empresas
                foreach (KeyValuePair<Thread, ParametroThread> item in threads)
                {
                    Thread t = item.Key;
                    t.Start(item.Value);
                    if (Empresa.Configuracoes.Count > 1)
                        Thread.Sleep(100);  //danasa 9-2010
                }
                //Limpar para tirar o conteúdo da memória pois não vamos mais precisar
                threads.Clear();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public bool consultarStatusNFe(out object retorno)
        {
            try
            {

                bool resultado = false;
                GerarXML gerarXML = new GerarXML(0);

                string XmlNfeDadosMsg = Empresa.Configuracoes[0].PastaEnvio + "\\" + gerarXML.StatusServico(TipoEmissao.teNormal, 53, TipoAmbiente.taHomologacao);

                Auxiliar oAux = new Auxiliar();

                string ArqXMLRetorno = Empresa.Configuracoes[0].PastaRetorno + "\\" +
                          oAux.ExtrairNomeArq(XmlNfeDadosMsg, ExtXml.PedSta) +
                          "-sta.xml";

                string ArqERRRetorno = Empresa.Configuracoes[0].PastaRetorno + "\\" +
                          oAux.ExtrairNomeArq(XmlNfeDadosMsg, ExtXml.PedSta) +
                          "-sta.err";

                object vRetorno = null;
                try
                {
                    resultado = EnviaArquivoERecebeResposta(1, ArqXMLRetorno, ArqERRRetorno, out retorno);
                }
                finally
                {
                    oAux.DeletarArquivo(ArqERRRetorno);
                    oAux.DeletarArquivo(ArqXMLRetorno);
                }
                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Envia um arquivo para o webservice da NFE e recebe a resposta. 
        /// </summary>
        /// <returns>Retorna uma string com a mensagem obtida do webservice de status do serviço da NFe</returns>
        /// <example>string vPastaArq = this.CriaArqXMLStatusServico();</example>
        /// <by>Wandrey Mundin Ferreira</by>
        /// <date>17/06/2009</date>
        private bool EnviaArquivoERecebeResposta(int tipo, string arqXMLRetorno, string arqERRRetorno, out object retorno)
        {
            object vStatus = "Ocorreu uma falha ao tentar obter a situação do serviço junto ao SEFAZ.\r\n\r\n" +
                "O problema pode ter ocorrido por causa dos seguintes fatores:\r\n\r\n" +
                "- Problema com o certificado digital\r\n" +
                "- Necessidade de atualização da cadeia de certificados digitais\r\n" +
                "- Falha de conexão com a internet\r\n" +
                "- Falha nos servidores do SEFAZ\r\n\r\n" +
                "Afirmamos que a produtora do software não se responsabiliza por decisões tomadas e/ou execuções realizadas com base nas informações acima.\r\n\r\n";

            bool resultado = false;
            DateTime startTime;
            DateTime stopTime;
            TimeSpan elapsedTime;

            long elapsedMillieconds;
            startTime = DateTime.Now;

            while (true)
            {
                stopTime = DateTime.Now;
                elapsedTime = stopTime.Subtract(startTime);
                elapsedMillieconds = (int)elapsedTime.TotalMilliseconds;

                if (elapsedMillieconds >= 30000) //120.000 ms que corresponde á 120 segundos que corresponde a 2 minutos
                {
                    break;
                }

                if (File.Exists(arqXMLRetorno))
                {
                    if (!Auxiliar.FileInUse(arqXMLRetorno))
                    {
                        try
                        {
                            //Ler o status do serviço no XML retornado pelo WebService
                            //XmlTextReader oLerXml = new XmlTextReader(ArqXMLRetorno);

                            try
                            {
                                GerarXML oGerar = new GerarXML(0);

                                if (tipo == 1)
                                    vStatus = ProcessaStatusServico(arqXMLRetorno);
                                else
                                    vStatus = oGerar.ProcessaConsultaCadastro(arqXMLRetorno);

                                resultado = true;
                            }
                            catch (Exception ex)
                            {
                                vStatus = ex.Message;
                                break;
                                //Se não conseguir ler o arquivo vai somente retornar ao loop para tentar novamente, pois 
                                //pode ser que o arquivo esteja em uso ainda.
                            }

                            //Detetar o arquivo de retorno
                            try
                            {
                                FileInfo oArquivoDel = new FileInfo(arqXMLRetorno);
                                oArquivoDel.Delete();
                                break;
                            }
                            catch
                            {
                                //Somente deixa fazer o loop novamente e tentar deletar
                            }
                        }
                        catch (Exception ex)
                        {
                            vStatus += ex.Message;
                        }
                    }

                }
                else if (File.Exists(arqERRRetorno))
                {
                    //Retornou um arquivo com a extensão .ERR, ou seja, deu um erro,
                    //futuramente tem que retornar esta mensagem para a MessageBox do usuário.

                    //Detetar o arquivo de retorno
                    try
                    {
                        vStatus += System.IO.File.ReadAllText(arqERRRetorno, Encoding.Default);
                        System.IO.File.Delete(arqERRRetorno);
                        break;
                    }
                    catch
                    {
                        //Somente deixa fazer o loop novamente e tentar deletar
                    }
                    resultado = false;
                }
                Thread.Sleep(3000);
            }

            //Retornar o status do serviço
            retorno = vStatus;
            return resultado;
        }
        public void pesquisarProduto()
        {
            try
            {
                SearchWindowApp searchWindow = new SearchWindowApp(typeof(ProdutoDTO), typeof(ServicoClientNFe));
                searchWindow.definirColunas(new string[] { "gtin", "nome", "valorVenda" });
                if (searchWindow.ShowDialog() == true)
                {
                    produtoSelected  = (ProdutoDTO)searchWindow.itemSelecionado;
                    detalheNFe = new NFeDetalheDTO();
                    notifyPropertyChanged("produtoSelected");
                    notifyPropertyChanged("detalheNFe");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Função Callback que analisa a resposta do Status do Servido
        /// </summary>
        /// <param name="elem"></param>
        /// <by>Marcos Diez</by>
        /// <date>30/8/2009</date>
        /// <returns></returns>
        private static string ProcessaStatusServico(string cArquivoXML)//XmlTextReader elem)
        {
            string rst = "Erro na leitura do XML " + cArquivoXML;
            XmlTextReader elem = new XmlTextReader(cArquivoXML);
            try
            {
                while (elem.Read())
                {
                    if (elem.NodeType == XmlNodeType.Element)
                    {
                        if (elem.Name == "xMotivo")
                        {
                            elem.Read();
                            rst = elem.Value;
                            break;
                        }
                    }
                }
            }
            finally
            {
                elem.Close();
            }

            return rst;
        }

        public void excluirCupomVinculado(int index)
        {
            try
            {
                if(nfeSelected.listaCupomFiscal.Count > index )
                    nfeSelected.listaCupomFiscal.RemoveAt(index);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public void excluirDuplicata(int index)
        {
            try
            {
                if (nfeSelected.fatura.listaDuplicata.Count > index)
                    nfeSelected.fatura.listaDuplicata.RemoveAt(index);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void excluirProduto(int index)
        {
            try
            {
                if (nfeSelected.listaDetalhe.Count > index)
                {
                    nfeSelected.listaDetalhe.RemoveAt(index);
                    atualizarNumeroItemDetalhe();
                    atualizarValoresNFe();
                }
                    
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public void incluirCupomVinculado(NFeCupomFiscalDTO cupomVinculado)
        {
            try
            {
                if (nfeSelected.listaCupomFiscal == null)
                    nfeSelected.listaCupomFiscal = new List<NFeCupomFiscalDTO>();

                nfeSelected.listaCupomFiscal.Add(cupomVinculado);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public void incluirDuplicata(NFeDuplicataDTO duplicata)
        {
            try
            {
                if (nfeSelected.fatura.listaDuplicata == null)
                    nfeSelected.fatura.listaDuplicata = new List<NFeDuplicataDTO>();

                nfeSelected.fatura.listaDuplicata.Add(duplicata);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public void carregarTabLista()
        {
            try
            {
                contentPresenterTabDados.Content = null;
                atualizarListaNFe();
                isSelectedTabLista = true;
                notifyPropertyChanged("isSelectedTabLista");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void carregarTabDados()
        {
            try
            {
                carregarNFeSelected();
                contentPresenterTabDados.Content = new NFeDados();
                isSelectedTabDados = true;
                notifyPropertyChanged("isSelectedTabDados");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void carregarNFeSelected()
        {
            try
            {
                if (nfeSelected != null && nfeSelected.id != null)
                {
                    using (NFeClient serv = new NFeClient())
                    {
                        nfeSelected = serv.selectNFeCabecalhoId((int)nfeSelected.id);
                    }
                }

                if(nfeSelected.destinatario == null)
                    nfeSelected.destinatario = new NFeDestinatarioDTO();
                if (nfeSelected.listaCupomFiscal == null)
                    nfeSelected.listaCupomFiscal = new List<NFeCupomFiscalDTO>();
                if (nfeSelected.localEntrega == null)
                    nfeSelected.localEntrega = new NFeLocalEntregaDTO();
                if (nfeSelected.localRetirada == null)
                    nfeSelected.localRetirada = new NFeLocalRetiradaDTO();
                if (nfeSelected.transporte == null)
                    nfeSelected.transporte = new NFeTransporteDTO();
                if (nfeSelected.listaDetalhe == null)
                    nfeSelected.listaDetalhe = new List<NFeDetalheDTO>();
                if (nfeSelected.fatura == null)
                {
                    nfeSelected.fatura = new NFeFaturaDTO();
                    nfeSelected.fatura.listaDuplicata = new List<NFeDuplicataDTO>();
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void atualizarListaNFe()
        {
            try
            {
                using (NFeClient serv = new NFeClient())
                {
                    List<NFeCabecalhoDTO> listaNFeServ = serv.selectNFeCabecalho(new NFeCabecalhoDTO());

                    listaNFe.Clear();

                    foreach (NFeCabecalhoDTO nfe in listaNFeServ)
                    {
                        listaNFe.Add(nfe);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void salvarNFe()
        {
            try
            {
                using (NFeClient serv = new NFeClient())
                {
                    nfeSelected.idEmpresa = empresa.id;
                    nfeSelected.versaoProcessoEmissao = 100;
                    nfeSelected.destinatario.ie = "";

                    if (nfeSelected.emitente == null)
                    {
                        NFeEmitenteDTO emitente = new NFeEmitenteDTO();
                        emitente.cpfCnpj = empresa.cnpj;
                        emitente.razaoSocial = empresa.razaoSocial;
                        emitente.fantasia = empresa.nomeFantasia;
                        emitente.logradouro = empresa.endereco.logradouro;
                        emitente.numero = empresa.endereco.numero;
                        emitente.complemento = empresa.endereco.complemento;
                        emitente.bairro = empresa.endereco.bairro;
                        emitente.codigoMunicipio = empresa.endereco.municipioIbge;
                        emitente.nomeMunicipio = "Brasilia";
                        emitente.uf = empresa.endereco.uf;
                        emitente.cep = empresa.endereco.cep;
                        emitente.crt = empresa.crt;
                        emitente.codigoPais = 1058;
                        emitente.nomePais = "Brasil";
                        emitente.telefone = empresa.endereco.fone;
                        emitente.ie = empresa.inscricaoEstadual;
                        emitente.iest = empresa.inscricaoEstadualST;
                        emitente.im = empresa.inscricaoMunicipal;

                        nfeSelected.emitente = emitente;
                    }                                        

                    serv.salvarNFeCabecalho(nfeSelected);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void imprimirDANFE()
        {
            try
            {
                Process unidanfe = new Process();
                unidanfe.StartInfo.FileName = @"C:\Unimake\UniNFe\unidanfe.exe";
                unidanfe.StartInfo.Arguments = " arquivo=\"" + Empresa.Configuracoes[0].PastaEnviado + "\\Autorizados\\"
                    + nfeSelected.dataEmissao.Value.Year
                    + nfeSelected.dataEmissao.Value.Month.ToString("00") + "\\"
                    + nfeSelected.chaveAcesso + nfeSelected.digitoChaveAcesso + "-nfe.xml\" ";
                unidanfe.Start();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void atualizarNumeroItemDetalhe()
        {
            try
            {
                int aux = 0;
                foreach (NFeDetalheDTO det in nfeSelected.listaDetalhe)
                {
                    det.numeroItem = ++aux;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void atualizarValoresNFe()
        {
            try
            {
                nfeSelected.baseCalculoICMS = 0;
                nfeSelected.valorICMS = 0;
                nfeSelected.baseCalculoICMS_ST = 0;
                nfeSelected.valorICMS_ST = 0;
                nfeSelected.valorCOFINS = 0;
                nfeSelected.valorTotalProdutos = 0;
                nfeSelected.valorFrete = 0;
                nfeSelected.valorSeguro = 0;
                nfeSelected.valorDespesasAcessorias = 0;
                nfeSelected.valorPIS = 0;
                nfeSelected.valorDesconto = 0;
                nfeSelected.valorTotal = 0;

                foreach(NFeDetalheDTO detalhe in nfeSelected.listaDetalhe)
                {
                    nfeSelected.valorTotal += detalhe.valorTotal;
                    nfeSelected.baseCalculoICMS += detalhe.baseCalculoICMS;
                    nfeSelected.valorICMS += detalhe.valorICMS;
                    nfeSelected.valorTotalProdutos += detalhe.valorTotal;


                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void incluirProduto(decimal quantidade)
        {
            try
            {
                if(produtoSelected == null)
                    throw new Exception("Selecione o produto.");

                if (nfeSelected.listaDetalhe == null)
                    nfeSelected.listaDetalhe = new List<NFeDetalheDTO>();

                detalheNFe.idProduto = produtoSelected.id;
                detalheNFe.codigoProduto = produtoSelected.gtin;
                detalheNFe.gtin = produtoSelected.gtin;
                detalheNFe.csosn = produtoSelected.tributacaoEstadual.csosn;
                detalheNFe.cstICMS = produtoSelected.tributacaoEstadual.cstB_ICMS;
                detalheNFe.baseCalculoICMS = produtoSelected.valorVenda;
                detalheNFe.aliquotaICMS = produtoSelected.tributacaoEstadual.taxaICMS;
                detalheNFe.valorICMS = (produtoSelected.valorVenda * produtoSelected.tributacaoEstadual.taxaICMS) / 100;
                detalheNFe.valorBrutoProdutos = quantidade * produtoSelected.valorVenda;
                detalheNFe.gtinUnidadeTributavel = produtoSelected.gtin;
                detalheNFe.quantidadeTributavel = quantidade;
                detalheNFe.valorUnitarioTributacao = produtoSelected.valorVenda;
                detalheNFe.nomeProduto = produtoSelected.nome;
                detalheNFe.quantidadeComercial = quantidade;
                detalheNFe.valorUnitarioComercial = produtoSelected.valorVenda;
                detalheNFe.valorSubtotal = quantidade * produtoSelected.valorVenda;
                detalheNFe.valorTotal = quantidade * produtoSelected.valorVenda;
                detalheNFe.ncm = produtoSelected.ncm.ncmCompleto;
                detalheNFe.unidadeComercial = produtoSelected.unidade.sigla;
                detalheNFe.unidadeTributavel = produtoSelected.unidade.sigla;
                detalheNFe.origemMercadoria = "0";
                detalheNFe.modalidadeBC_ICMS = "3";
                detalheNFe.cstPIS = "99";
                detalheNFe.valorBaseCalculoPIS = 0;
                detalheNFe.valorPIS = 0;
                detalheNFe.cstCOFINS = "99";
                detalheNFe.baseCalculoCOFINS = 0;
                detalheNFe.valorCOFINS = 0;

                nfeSelected.listaDetalhe.Add(detalheNFe);

                atualizarNumeroItemDetalhe();
                atualizarValoresNFe();

                produtoSelected = null;
                detalheNFe = null;

                notifyPropertyChanged("produtoSelected");
                notifyPropertyChanged("detalheNFe");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
