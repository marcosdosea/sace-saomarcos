﻿namespace UniNFeLibrary.Formulario
{
    partial class Configuracao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Configuracao));
            this.textBox_PastaEnvioXML = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_PastaRetornoXML = new System.Windows.Forms.TextBox();
            this.comboBox_UF = new System.Windows.Forms.ComboBox();
            this.comboBox_Ambiente = new System.Windows.Forms.ComboBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton_salvar = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton_fechar = new System.Windows.Forms.ToolStripButton();
            this.folderBrowserDialog_xmlenvio = new System.Windows.Forms.FolderBrowserDialog();
            this.folderBrowserDialog_xmlretorno = new System.Windows.Forms.FolderBrowserDialog();
            this.textBox_dadoscertificado = new System.Windows.Forms.TextBox();
            this.textBox_PastaEnviados = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.checkBoxRetornoNFETxt = new System.Windows.Forms.CheckBox();
            this.comboBox_tpEmis = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.udDiasLimpeza = new System.Windows.Forms.NumericUpDown();
            this.label14 = new System.Windows.Forms.Label();
            this.cboDiretorioSalvarComo = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tbPastaValidar = new System.Windows.Forms.TextBox();
            this.tbPastaLote = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox_PastaBackup = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox_PastaXmlErro = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.button_SelectPastaValidar = new System.Windows.Forms.Button();
            this.btnSelectPastaLote = new System.Windows.Forms.Button();
            this.button_SelectPastaBackup = new System.Windows.Forms.Button();
            this.button_SelectPastaXmlErro = new System.Windows.Forms.Button();
            this.button_SelectPastaXmlEnviado = new System.Windows.Forms.Button();
            this.button_selectxmlenvio = new System.Windows.Forms.Button();
            this.button_SelectPastaXmlRetorno = new System.Windows.Forms.Button();
            this.button_selecionar_certificado = new System.Windows.Forms.Button();
            this.tbServidor = new System.Windows.Forms.TextBox();
            this.lblServidor = new System.Windows.Forms.Label();
            this.nudPorta = new System.Windows.Forms.NumericUpDown();
            this.tbSenha = new System.Windows.Forms.TextBox();
            this.tbUsuario = new System.Windows.Forms.TextBox();
            this.cbProxy = new System.Windows.Forms.CheckBox();
            this.lblSenha = new System.Windows.Forms.Label();
            this.lblPorta = new System.Windows.Forms.Label();
            this.lblUsuario = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.cbDanfeMonProcNfe = new System.Windows.Forms.CheckBox();
            this.cbDanfeMonNfe = new System.Windows.Forms.CheckBox();
            this.tbPastaXmlParaDanfeMon = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.tbPastaConfigUniDanfe = new System.Windows.Forms.TextBox();
            this.tbPastaExeUniDanfe = new System.Windows.Forms.TextBox();
            this.tbTextoDANFE = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btnSelectPastaParaXmlDanfeMon = new System.Windows.Forms.Button();
            this.button_SelectPastaConfUniDanfe = new System.Windows.Forms.Button();
            this.button_SelectPastaExeUniDanfe = new System.Windows.Forms.Button();
            this.folderBrowserDialog_xmlenviado = new System.Windows.Forms.FolderBrowserDialog();
            this.folderBrowserDialog_xmlerro = new System.Windows.Forms.FolderBrowserDialog();
            this.folderBrowserDialog_backup = new System.Windows.Forms.FolderBrowserDialog();
            this.folderBrowserDialog_xmlenviolote = new System.Windows.Forms.FolderBrowserDialog();
            this.folderBrowserDialog_Validar = new System.Windows.Forms.FolderBrowserDialog();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPageGeral = new System.Windows.Forms.TabPage();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.tabPageEmpresa = new System.Windows.Forms.TabPage();
            this.cbEmpresa = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.udDiasLimpeza)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPorta)).BeginInit();
            this.tabControl2.SuspendLayout();
            this.tabPageGeral.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPageEmpresa.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox_PastaEnvioXML
            // 
            this.textBox_PastaEnvioXML.AccessibleDescription = "";
            this.textBox_PastaEnvioXML.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox_PastaEnvioXML.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
            this.textBox_PastaEnvioXML.Location = new System.Drawing.Point(4, 22);
            this.textBox_PastaEnvioXML.Name = "textBox_PastaEnvioXML";
            this.textBox_PastaEnvioXML.Size = new System.Drawing.Size(542, 20);
            this.textBox_PastaEnvioXML.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(486, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Pasta onde será gravado os arquivos XML´s a serem enviados individualmente para o" +
                "s WebServices:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(357, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Pasta onde será gravado os arquivos XML´s de retorno dos WebServices:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(162, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Unidade Federativa (UF-Estado):";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Ambiente:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(225, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Informações do certificado digital selecionado:";
            // 
            // textBox_PastaRetornoXML
            // 
            this.textBox_PastaRetornoXML.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox_PastaRetornoXML.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
            this.textBox_PastaRetornoXML.Location = new System.Drawing.Point(4, 112);
            this.textBox_PastaRetornoXML.Name = "textBox_PastaRetornoXML";
            this.textBox_PastaRetornoXML.Size = new System.Drawing.Size(542, 20);
            this.textBox_PastaRetornoXML.TabIndex = 10;
            // 
            // comboBox_UF
            // 
            this.comboBox_UF.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_UF.FormattingEnabled = true;
            this.comboBox_UF.ItemHeight = 13;
            this.comboBox_UF.Location = new System.Drawing.Point(4, 22);
            this.comboBox_UF.Name = "comboBox_UF";
            this.comboBox_UF.Size = new System.Drawing.Size(173, 21);
            this.comboBox_UF.TabIndex = 8;
            // 
            // comboBox_Ambiente
            // 
            this.comboBox_Ambiente.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Ambiente.FormattingEnabled = true;
            this.comboBox_Ambiente.ItemHeight = 13;
            this.comboBox_Ambiente.Location = new System.Drawing.Point(4, 69);
            this.comboBox_Ambiente.Name = "comboBox_Ambiente";
            this.comboBox_Ambiente.Size = new System.Drawing.Size(173, 21);
            this.comboBox_Ambiente.TabIndex = 10;
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton_salvar,
            this.toolStripButton_fechar});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(611, 39);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton_salvar
            // 
            this.toolStripButton_salvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_salvar.Image = global::UniNFeLibrary.Properties.Resources.filesave;
            this.toolStripButton_salvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_salvar.Name = "toolStripButton_salvar";
            this.toolStripButton_salvar.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton_salvar.Text = "toolStripButton1";
            this.toolStripButton_salvar.ToolTipText = "Salvar as alterações e fechar a tela";
            this.toolStripButton_salvar.Click += new System.EventHandler(this.toolStripButton_salvar_Click);
            // 
            // toolStripButton_fechar
            // 
            this.toolStripButton_fechar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_fechar.Image = global::UniNFeLibrary.Properties.Resources.fileclose;
            this.toolStripButton_fechar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_fechar.Name = "toolStripButton_fechar";
            this.toolStripButton_fechar.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton_fechar.Text = "toolStripButton2";
            this.toolStripButton_fechar.ToolTipText = "Fechar a tela sem salvar as alterações";
            this.toolStripButton_fechar.Click += new System.EventHandler(this.toolStripButton_fechar_Click);
            // 
            // folderBrowserDialog_xmlenvio
            // 
            this.folderBrowserDialog_xmlenvio.RootFolder = System.Environment.SpecialFolder.MyComputer;
            // 
            // folderBrowserDialog_xmlretorno
            // 
            this.folderBrowserDialog_xmlretorno.RootFolder = System.Environment.SpecialFolder.MyComputer;
            // 
            // textBox_dadoscertificado
            // 
            this.textBox_dadoscertificado.Location = new System.Drawing.Point(6, 22);
            this.textBox_dadoscertificado.Multiline = true;
            this.textBox_dadoscertificado.Name = "textBox_dadoscertificado";
            this.textBox_dadoscertificado.ReadOnly = true;
            this.textBox_dadoscertificado.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_dadoscertificado.Size = new System.Drawing.Size(516, 284);
            this.textBox_dadoscertificado.TabIndex = 18;
            // 
            // textBox_PastaEnviados
            // 
            this.textBox_PastaEnviados.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox_PastaEnviados.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
            this.textBox_PastaEnviados.Location = new System.Drawing.Point(4, 158);
            this.textBox_PastaEnviados.Name = "textBox_PastaEnviados";
            this.textBox_PastaEnviados.Size = new System.Drawing.Size(542, 20);
            this.textBox_PastaEnviados.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1, 142);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(265, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Pasta onde será gravado os arquivos XML´s enviados:";
            // 
            // checkBoxRetornoNFETxt
            // 
            this.checkBoxRetornoNFETxt.AutoSize = true;
            this.checkBoxRetornoNFETxt.Location = new System.Drawing.Point(4, 291);
            this.checkBoxRetornoNFETxt.Name = "checkBoxRetornoNFETxt";
            this.checkBoxRetornoNFETxt.Size = new System.Drawing.Size(344, 17);
            this.checkBoxRetornoNFETxt.TabIndex = 13;
            this.checkBoxRetornoNFETxt.Text = "Gravar os retornos dos webservices também no formato texto (TXT)";
            this.checkBoxRetornoNFETxt.UseVisualStyleBackColor = true;
            // 
            // comboBox_tpEmis
            // 
            this.comboBox_tpEmis.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_tpEmis.FormattingEnabled = true;
            this.comboBox_tpEmis.ItemHeight = 13;
            this.comboBox_tpEmis.Location = new System.Drawing.Point(4, 117);
            this.comboBox_tpEmis.Name = "comboBox_tpEmis";
            this.comboBox_tpEmis.Size = new System.Drawing.Size(284, 21);
            this.comboBox_tpEmis.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1, 100);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 13);
            this.label8.TabIndex = 9;
            this.label8.Text = "Tipo de Emissão:";
            // 
            // udDiasLimpeza
            // 
            this.udDiasLimpeza.Location = new System.Drawing.Point(4, 211);
            this.udDiasLimpeza.Maximum = new decimal(new int[] {
            7305,
            0,
            0,
            0});
            this.udDiasLimpeza.Name = "udDiasLimpeza";
            this.udDiasLimpeza.Size = new System.Drawing.Size(85, 20);
            this.udDiasLimpeza.TabIndex = 32;
            this.udDiasLimpeza.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(1, 189);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(489, 19);
            this.label14.TabIndex = 31;
            this.label14.Text = "Quantos dias devem ser mantidos os arquivos na pasta temporário e retorno? Deixe " +
                "0 para infinito.";
            // 
            // cboDiretorioSalvarComo
            // 
            this.cboDiretorioSalvarComo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDiretorioSalvarComo.FormattingEnabled = true;
            this.cboDiretorioSalvarComo.Items.AddRange(new object[] {
            "AMD",
            "AM",
            "AD",
            "MDA",
            "MD",
            "MA",
            "DMA",
            "DM",
            "DA",
            "A\\M\\D",
            "A\\M",
            "A\\D",
            "M\\D\\A",
            "M\\D",
            "M\\A",
            "D\\M\\A",
            "D\\M",
            "D\\A"});
            this.cboDiretorioSalvarComo.Location = new System.Drawing.Point(4, 165);
            this.cboDiretorioSalvarComo.Name = "cboDiretorioSalvarComo";
            this.cboDiretorioSalvarComo.Size = new System.Drawing.Size(85, 21);
            this.cboDiretorioSalvarComo.TabIndex = 30;
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(1, 146);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(342, 17);
            this.label13.TabIndex = 29;
            this.label13.Text = "Como devem ser criados os diretórios baseados na data de emissão?";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1, 272);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(350, 13);
            this.label12.TabIndex = 28;
            this.label12.Text = "Pasta onde será gravado os arquivos XML´s a serem somente validados:";
            // 
            // tbPastaValidar
            // 
            this.tbPastaValidar.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.tbPastaValidar.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
            this.tbPastaValidar.Location = new System.Drawing.Point(5, 287);
            this.tbPastaValidar.Name = "tbPastaValidar";
            this.tbPastaValidar.Size = new System.Drawing.Size(542, 20);
            this.tbPastaValidar.TabIndex = 26;
            // 
            // tbPastaLote
            // 
            this.tbPastaLote.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.tbPastaLote.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
            this.tbPastaLote.Location = new System.Drawing.Point(4, 66);
            this.tbPastaLote.Name = "tbPastaLote";
            this.tbPastaLote.Size = new System.Drawing.Size(542, 20);
            this.tbPastaLote.TabIndex = 8;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1, 49);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(488, 13);
            this.label11.TabIndex = 25;
            this.label11.Text = "Pasta onde será gravado os arquivos XML´s de NF-e a serem enviadas em lote para o" +
                "s WebServices:";
            // 
            // textBox_PastaBackup
            // 
            this.textBox_PastaBackup.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox_PastaBackup.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
            this.textBox_PastaBackup.Location = new System.Drawing.Point(4, 247);
            this.textBox_PastaBackup.Name = "textBox_PastaBackup";
            this.textBox_PastaBackup.Size = new System.Drawing.Size(542, 20);
            this.textBox_PastaBackup.TabIndex = 16;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1, 231);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(200, 13);
            this.label10.TabIndex = 22;
            this.label10.Text = "Pasta para Backup dos XML´s enviados:";
            // 
            // textBox_PastaXmlErro
            // 
            this.textBox_PastaXmlErro.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox_PastaXmlErro.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
            this.textBox_PastaXmlErro.Location = new System.Drawing.Point(4, 204);
            this.textBox_PastaXmlErro.Name = "textBox_PastaXmlErro";
            this.textBox_PastaXmlErro.Size = new System.Drawing.Size(542, 20);
            this.textBox_PastaXmlErro.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1, 187);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(445, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "Pasta para arquivamento temporário dos XML´s que apresentaram erro na tentativa d" +
                "o envio:";
            // 
            // button_SelectPastaValidar
            // 
            this.button_SelectPastaValidar.Image = global::UniNFeLibrary.Properties.Resources.folder_orange_open;
            this.button_SelectPastaValidar.Location = new System.Drawing.Point(553, 287);
            this.button_SelectPastaValidar.Name = "button_SelectPastaValidar";
            this.button_SelectPastaValidar.Size = new System.Drawing.Size(27, 23);
            this.button_SelectPastaValidar.TabIndex = 27;
            this.button_SelectPastaValidar.UseVisualStyleBackColor = true;
            this.button_SelectPastaValidar.Click += new System.EventHandler(this.button_SelectPastaValidar_Click);
            // 
            // btnSelectPastaLote
            // 
            this.btnSelectPastaLote.Image = global::UniNFeLibrary.Properties.Resources.folder_orange_open;
            this.btnSelectPastaLote.Location = new System.Drawing.Point(552, 66);
            this.btnSelectPastaLote.Name = "btnSelectPastaLote";
            this.btnSelectPastaLote.Size = new System.Drawing.Size(27, 23);
            this.btnSelectPastaLote.TabIndex = 9;
            this.btnSelectPastaLote.UseVisualStyleBackColor = true;
            this.btnSelectPastaLote.Click += new System.EventHandler(this.btnSelectPastaLote_Click);
            // 
            // button_SelectPastaBackup
            // 
            this.button_SelectPastaBackup.Image = global::UniNFeLibrary.Properties.Resources.folder_orange_open;
            this.button_SelectPastaBackup.Location = new System.Drawing.Point(552, 247);
            this.button_SelectPastaBackup.Name = "button_SelectPastaBackup";
            this.button_SelectPastaBackup.Size = new System.Drawing.Size(27, 23);
            this.button_SelectPastaBackup.TabIndex = 17;
            this.button_SelectPastaBackup.UseVisualStyleBackColor = true;
            this.button_SelectPastaBackup.Click += new System.EventHandler(this.button_SelectPastaBackup_Click);
            // 
            // button_SelectPastaXmlErro
            // 
            this.button_SelectPastaXmlErro.Image = global::UniNFeLibrary.Properties.Resources.folder_orange_open;
            this.button_SelectPastaXmlErro.Location = new System.Drawing.Point(552, 202);
            this.button_SelectPastaXmlErro.Name = "button_SelectPastaXmlErro";
            this.button_SelectPastaXmlErro.Size = new System.Drawing.Size(27, 23);
            this.button_SelectPastaXmlErro.TabIndex = 15;
            this.button_SelectPastaXmlErro.UseVisualStyleBackColor = true;
            this.button_SelectPastaXmlErro.Click += new System.EventHandler(this.button_SelectPastaXmlErro_Click);
            // 
            // button_SelectPastaXmlEnviado
            // 
            this.button_SelectPastaXmlEnviado.Image = global::UniNFeLibrary.Properties.Resources.folder_orange_open;
            this.button_SelectPastaXmlEnviado.Location = new System.Drawing.Point(552, 156);
            this.button_SelectPastaXmlEnviado.Name = "button_SelectPastaXmlEnviado";
            this.button_SelectPastaXmlEnviado.Size = new System.Drawing.Size(27, 23);
            this.button_SelectPastaXmlEnviado.TabIndex = 13;
            this.button_SelectPastaXmlEnviado.UseVisualStyleBackColor = true;
            this.button_SelectPastaXmlEnviado.Click += new System.EventHandler(this.button_SelectPastaXmlEnviado_Click);
            // 
            // button_selectxmlenvio
            // 
            this.button_selectxmlenvio.Image = global::UniNFeLibrary.Properties.Resources.folder_orange_open;
            this.button_selectxmlenvio.Location = new System.Drawing.Point(552, 20);
            this.button_selectxmlenvio.Name = "button_selectxmlenvio";
            this.button_selectxmlenvio.Size = new System.Drawing.Size(27, 23);
            this.button_selectxmlenvio.TabIndex = 7;
            this.button_selectxmlenvio.UseVisualStyleBackColor = true;
            this.button_selectxmlenvio.Click += new System.EventHandler(this.button_selectxmlenvio_Click);
            // 
            // button_SelectPastaXmlRetorno
            // 
            this.button_SelectPastaXmlRetorno.Image = global::UniNFeLibrary.Properties.Resources.folder_orange_open;
            this.button_SelectPastaXmlRetorno.Location = new System.Drawing.Point(552, 110);
            this.button_SelectPastaXmlRetorno.Name = "button_SelectPastaXmlRetorno";
            this.button_SelectPastaXmlRetorno.Size = new System.Drawing.Size(27, 23);
            this.button_SelectPastaXmlRetorno.TabIndex = 11;
            this.button_SelectPastaXmlRetorno.UseVisualStyleBackColor = true;
            this.button_SelectPastaXmlRetorno.Click += new System.EventHandler(this.button_SelectPastaXmlRetorno_Click);
            // 
            // button_selecionar_certificado
            // 
            this.button_selecionar_certificado.Image = global::UniNFeLibrary.Properties.Resources.identity1;
            this.button_selecionar_certificado.Location = new System.Drawing.Point(524, 22);
            this.button_selecionar_certificado.Name = "button_selecionar_certificado";
            this.button_selecionar_certificado.Size = new System.Drawing.Size(69, 54);
            this.button_selecionar_certificado.TabIndex = 19;
            this.button_selecionar_certificado.UseVisualStyleBackColor = true;
            this.button_selecionar_certificado.Click += new System.EventHandler(this.button_selecionar_certificado_Click);
            // 
            // tbServidor
            // 
            this.tbServidor.Enabled = false;
            this.tbServidor.Location = new System.Drawing.Point(59, 111);
            this.tbServidor.Name = "tbServidor";
            this.tbServidor.Size = new System.Drawing.Size(327, 20);
            this.tbServidor.TabIndex = 8;
            // 
            // lblServidor
            // 
            this.lblServidor.AutoSize = true;
            this.lblServidor.Enabled = false;
            this.lblServidor.Location = new System.Drawing.Point(6, 114);
            this.lblServidor.Name = "lblServidor";
            this.lblServidor.Size = new System.Drawing.Size(49, 13);
            this.lblServidor.TabIndex = 7;
            this.lblServidor.Text = "Servidor:";
            // 
            // nudPorta
            // 
            this.nudPorta.Enabled = false;
            this.nudPorta.Location = new System.Drawing.Point(59, 85);
            this.nudPorta.Maximum = new decimal(new int[] {
            1410065407,
            2,
            0,
            0});
            this.nudPorta.Name = "nudPorta";
            this.nudPorta.Size = new System.Drawing.Size(71, 20);
            this.nudPorta.TabIndex = 6;
            this.nudPorta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbSenha
            // 
            this.tbSenha.Enabled = false;
            this.tbSenha.Location = new System.Drawing.Point(59, 56);
            this.tbSenha.Name = "tbSenha";
            this.tbSenha.PasswordChar = '●';
            this.tbSenha.Size = new System.Drawing.Size(216, 20);
            this.tbSenha.TabIndex = 5;
            // 
            // tbUsuario
            // 
            this.tbUsuario.Enabled = false;
            this.tbUsuario.Location = new System.Drawing.Point(59, 30);
            this.tbUsuario.Name = "tbUsuario";
            this.tbUsuario.Size = new System.Drawing.Size(327, 20);
            this.tbUsuario.TabIndex = 4;
            // 
            // cbProxy
            // 
            this.cbProxy.AutoSize = true;
            this.cbProxy.Location = new System.Drawing.Point(9, 7);
            this.cbProxy.Name = "cbProxy";
            this.cbProxy.Size = new System.Drawing.Size(133, 17);
            this.cbProxy.TabIndex = 3;
            this.cbProxy.Text = "Usar um servidor proxy";
            this.cbProxy.UseVisualStyleBackColor = true;
            this.cbProxy.CheckedChanged += new System.EventHandler(this.cbProxy_CheckedChanged);
            // 
            // lblSenha
            // 
            this.lblSenha.AutoSize = true;
            this.lblSenha.Enabled = false;
            this.lblSenha.Location = new System.Drawing.Point(6, 58);
            this.lblSenha.Name = "lblSenha";
            this.lblSenha.Size = new System.Drawing.Size(41, 13);
            this.lblSenha.TabIndex = 2;
            this.lblSenha.Text = "Senha:";
            // 
            // lblPorta
            // 
            this.lblPorta.AutoSize = true;
            this.lblPorta.Enabled = false;
            this.lblPorta.Location = new System.Drawing.Point(6, 88);
            this.lblPorta.Name = "lblPorta";
            this.lblPorta.Size = new System.Drawing.Size(35, 13);
            this.lblPorta.TabIndex = 1;
            this.lblPorta.Text = "Porta:";
            // 
            // lblUsuario
            // 
            this.lblUsuario.AutoSize = true;
            this.lblUsuario.Enabled = false;
            this.lblUsuario.Location = new System.Drawing.Point(6, 31);
            this.lblUsuario.Name = "lblUsuario";
            this.lblUsuario.Size = new System.Drawing.Size(46, 13);
            this.lblUsuario.TabIndex = 0;
            this.lblUsuario.Text = "Usuário:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(1, 244);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(407, 13);
            this.label18.TabIndex = 13;
            this.label18.Text = "XML´s a serem copiados na pasta para impressão do DANFE a partir do DANFeMon:";
            // 
            // cbDanfeMonProcNfe
            // 
            this.cbDanfeMonProcNfe.AutoSize = true;
            this.cbDanfeMonProcNfe.Location = new System.Drawing.Point(33, 289);
            this.cbDanfeMonProcNfe.Name = "cbDanfeMonProcNfe";
            this.cbDanfeMonProcNfe.Size = new System.Drawing.Size(305, 17);
            this.cbDanfeMonProcNfe.TabIndex = 12;
            this.cbDanfeMonProcNfe.Text = "XML de distribuição da nota fiscal eletrônica (-procNFe.xml)";
            this.cbDanfeMonProcNfe.UseVisualStyleBackColor = true;
            // 
            // cbDanfeMonNfe
            // 
            this.cbDanfeMonNfe.AutoSize = true;
            this.cbDanfeMonNfe.Location = new System.Drawing.Point(33, 265);
            this.cbDanfeMonNfe.Name = "cbDanfeMonNfe";
            this.cbDanfeMonNfe.Size = new System.Drawing.Size(208, 17);
            this.cbDanfeMonNfe.TabIndex = 11;
            this.cbDanfeMonNfe.Text = "XML da nota fiscal eletrônica (-nfe.xml)";
            this.cbDanfeMonNfe.UseVisualStyleBackColor = true;
            // 
            // tbPastaXmlParaDanfeMon
            // 
            this.tbPastaXmlParaDanfeMon.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.tbPastaXmlParaDanfeMon.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
            this.tbPastaXmlParaDanfeMon.Location = new System.Drawing.Point(4, 210);
            this.tbPastaXmlParaDanfeMon.Name = "tbPastaXmlParaDanfeMon";
            this.tbPastaXmlParaDanfeMon.Size = new System.Drawing.Size(542, 20);
            this.tbPastaXmlParaDanfeMon.TabIndex = 9;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(1, 194);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(467, 13);
            this.label17.TabIndex = 8;
            this.label17.Text = "Pasta onde deve ser gravado o XML da NFe para a impressão do DANFe a partir do DA" +
                "NFeMon:";
            // 
            // tbPastaConfigUniDanfe
            // 
            this.tbPastaConfigUniDanfe.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.tbPastaConfigUniDanfe.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
            this.tbPastaConfigUniDanfe.Location = new System.Drawing.Point(4, 162);
            this.tbPastaConfigUniDanfe.Name = "tbPastaConfigUniDanfe";
            this.tbPastaConfigUniDanfe.Size = new System.Drawing.Size(542, 20);
            this.tbPastaConfigUniDanfe.TabIndex = 6;
            // 
            // tbPastaExeUniDanfe
            // 
            this.tbPastaExeUniDanfe.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.tbPastaExeUniDanfe.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystemDirectories;
            this.tbPastaExeUniDanfe.Location = new System.Drawing.Point(4, 118);
            this.tbPastaExeUniDanfe.Name = "tbPastaExeUniDanfe";
            this.tbPastaExeUniDanfe.Size = new System.Drawing.Size(542, 20);
            this.tbPastaExeUniDanfe.TabIndex = 4;
            // 
            // tbTextoDANFE
            // 
            this.tbTextoDANFE.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbTextoDANFE.Location = new System.Drawing.Point(4, 3);
            this.tbTextoDANFE.Multiline = true;
            this.tbTextoDANFE.Name = "tbTextoDANFE";
            this.tbTextoDANFE.Size = new System.Drawing.Size(576, 75);
            this.tbTextoDANFE.TabIndex = 3;
            this.tbTextoDANFE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(1, 145);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(244, 13);
            this.label16.TabIndex = 1;
            this.label16.Text = "Pasta do arquivo de configurações do UniDANFe:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(1, 102);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(176, 13);
            this.label15.TabIndex = 0;
            this.label15.Text = "Pasta do executável do UniDANFe:";
            // 
            // btnSelectPastaParaXmlDanfeMon
            // 
            this.btnSelectPastaParaXmlDanfeMon.Image = global::UniNFeLibrary.Properties.Resources.folder_orange_open;
            this.btnSelectPastaParaXmlDanfeMon.Location = new System.Drawing.Point(551, 208);
            this.btnSelectPastaParaXmlDanfeMon.Name = "btnSelectPastaParaXmlDanfeMon";
            this.btnSelectPastaParaXmlDanfeMon.Size = new System.Drawing.Size(27, 23);
            this.btnSelectPastaParaXmlDanfeMon.TabIndex = 10;
            this.btnSelectPastaParaXmlDanfeMon.UseVisualStyleBackColor = true;
            this.btnSelectPastaParaXmlDanfeMon.Click += new System.EventHandler(this.btnSelectPastaParaXmlDanfeMon_Click);
            // 
            // button_SelectPastaConfUniDanfe
            // 
            this.button_SelectPastaConfUniDanfe.Image = global::UniNFeLibrary.Properties.Resources.folder_orange_open;
            this.button_SelectPastaConfUniDanfe.Location = new System.Drawing.Point(551, 160);
            this.button_SelectPastaConfUniDanfe.Name = "button_SelectPastaConfUniDanfe";
            this.button_SelectPastaConfUniDanfe.Size = new System.Drawing.Size(27, 23);
            this.button_SelectPastaConfUniDanfe.TabIndex = 7;
            this.button_SelectPastaConfUniDanfe.UseVisualStyleBackColor = true;
            this.button_SelectPastaConfUniDanfe.Click += new System.EventHandler(this.button_SelectPastaConfUniDanfe_Click);
            // 
            // button_SelectPastaExeUniDanfe
            // 
            this.button_SelectPastaExeUniDanfe.Image = global::UniNFeLibrary.Properties.Resources.folder_orange_open;
            this.button_SelectPastaExeUniDanfe.Location = new System.Drawing.Point(551, 116);
            this.button_SelectPastaExeUniDanfe.Name = "button_SelectPastaExeUniDanfe";
            this.button_SelectPastaExeUniDanfe.Size = new System.Drawing.Size(27, 23);
            this.button_SelectPastaExeUniDanfe.TabIndex = 5;
            this.button_SelectPastaExeUniDanfe.UseVisualStyleBackColor = true;
            this.button_SelectPastaExeUniDanfe.Click += new System.EventHandler(this.button_SelectPastaExeUniDanfe_Click);
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ShowAlways = true;
            this.toolTip1.ToolTipTitle = "As pastas informadas não podem se repetir";
            // 
            // tabControl2
            // 
            this.tabControl2.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl2.Controls.Add(this.tabPageGeral);
            this.tabControl2.Controls.Add(this.tabPageEmpresa);
            this.tabControl2.Location = new System.Drawing.Point(0, 39);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(616, 414);
            this.tabControl2.TabIndex = 21;
            // 
            // tabPageGeral
            // 
            this.tabPageGeral.Controls.Add(this.tabControl4);
            this.tabPageGeral.Location = new System.Drawing.Point(4, 25);
            this.tabPageGeral.Name = "tabPageGeral";
            this.tabPageGeral.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageGeral.Size = new System.Drawing.Size(608, 385);
            this.tabPageGeral.TabIndex = 0;
            this.tabPageGeral.Text = "Geral";
            this.tabPageGeral.UseVisualStyleBackColor = true;
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage9);
            this.tabControl4.Location = new System.Drawing.Point(0, 0);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(604, 385);
            this.tabControl4.TabIndex = 0;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.tbServidor);
            this.tabPage9.Controls.Add(this.lblServidor);
            this.tabPage9.Controls.Add(this.lblUsuario);
            this.tabPage9.Controls.Add(this.nudPorta);
            this.tabPage9.Controls.Add(this.lblPorta);
            this.tabPage9.Controls.Add(this.tbSenha);
            this.tabPage9.Controls.Add(this.lblSenha);
            this.tabPage9.Controls.Add(this.tbUsuario);
            this.tabPage9.Controls.Add(this.cbProxy);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(596, 359);
            this.tabPage9.TabIndex = 0;
            this.tabPage9.Text = "Proxy";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // tabPageEmpresa
            // 
            this.tabPageEmpresa.Controls.Add(this.cbEmpresa);
            this.tabPageEmpresa.Controls.Add(this.label19);
            this.tabPageEmpresa.Controls.Add(this.tabControl3);
            this.tabPageEmpresa.Location = new System.Drawing.Point(4, 25);
            this.tabPageEmpresa.Name = "tabPageEmpresa";
            this.tabPageEmpresa.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageEmpresa.Size = new System.Drawing.Size(608, 385);
            this.tabPageEmpresa.TabIndex = 1;
            this.tabPageEmpresa.Text = "Por Empresa";
            this.tabPageEmpresa.UseVisualStyleBackColor = true;
            // 
            // cbEmpresa
            // 
            this.cbEmpresa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbEmpresa.FormattingEnabled = true;
            this.cbEmpresa.Location = new System.Drawing.Point(1, 21);
            this.cbEmpresa.Name = "cbEmpresa";
            this.cbEmpresa.Size = new System.Drawing.Size(599, 21);
            this.cbEmpresa.TabIndex = 2;
            this.cbEmpresa.SelectionChangeCommitted += new System.EventHandler(this.cbEmpresa_SelectionChangeCommitted);
            this.cbEmpresa.DropDown += new System.EventHandler(this.cbEmpresa_DropDown);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(-2, 3);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(195, 13);
            this.label19.TabIndex = 1;
            this.label19.Text = "Selecione a Empresa a ser configurada:";
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage6);
            this.tabControl3.Controls.Add(this.tabPage7);
            this.tabControl3.Controls.Add(this.tabPage3);
            this.tabControl3.Controls.Add(this.tabPage8);
            this.tabControl3.Location = new System.Drawing.Point(0, 47);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(604, 338);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.udDiasLimpeza);
            this.tabPage6.Controls.Add(this.label3);
            this.tabPage6.Controls.Add(this.label4);
            this.tabPage6.Controls.Add(this.label14);
            this.tabPage6.Controls.Add(this.label13);
            this.tabPage6.Controls.Add(this.comboBox_Ambiente);
            this.tabPage6.Controls.Add(this.cboDiretorioSalvarComo);
            this.tabPage6.Controls.Add(this.label8);
            this.tabPage6.Controls.Add(this.comboBox_tpEmis);
            this.tabPage6.Controls.Add(this.checkBoxRetornoNFETxt);
            this.tabPage6.Controls.Add(this.comboBox_UF);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(596, 312);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "Geral";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.label1);
            this.tabPage7.Controls.Add(this.button_SelectPastaXmlRetorno);
            this.tabPage7.Controls.Add(this.button_selectxmlenvio);
            this.tabPage7.Controls.Add(this.button_SelectPastaXmlEnviado);
            this.tabPage7.Controls.Add(this.label12);
            this.tabPage7.Controls.Add(this.button_SelectPastaXmlErro);
            this.tabPage7.Controls.Add(this.tbPastaValidar);
            this.tabPage7.Controls.Add(this.button_SelectPastaBackup);
            this.tabPage7.Controls.Add(this.tbPastaLote);
            this.tabPage7.Controls.Add(this.btnSelectPastaLote);
            this.tabPage7.Controls.Add(this.label11);
            this.tabPage7.Controls.Add(this.button_SelectPastaValidar);
            this.tabPage7.Controls.Add(this.textBox_PastaBackup);
            this.tabPage7.Controls.Add(this.textBox_PastaEnviados);
            this.tabPage7.Controls.Add(this.label10);
            this.tabPage7.Controls.Add(this.label6);
            this.tabPage7.Controls.Add(this.textBox_PastaXmlErro);
            this.tabPage7.Controls.Add(this.textBox_PastaRetornoXML);
            this.tabPage7.Controls.Add(this.label7);
            this.tabPage7.Controls.Add(this.label2);
            this.tabPage7.Controls.Add(this.textBox_PastaEnvioXML);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(596, 312);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "Pastas";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.textBox_dadoscertificado);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.button_selecionar_certificado);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(596, 312);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Certificado digital";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.label18);
            this.tabPage8.Controls.Add(this.tbTextoDANFE);
            this.tabPage8.Controls.Add(this.cbDanfeMonProcNfe);
            this.tabPage8.Controls.Add(this.button_SelectPastaExeUniDanfe);
            this.tabPage8.Controls.Add(this.cbDanfeMonNfe);
            this.tabPage8.Controls.Add(this.button_SelectPastaConfUniDanfe);
            this.tabPage8.Controls.Add(this.tbPastaXmlParaDanfeMon);
            this.tabPage8.Controls.Add(this.btnSelectPastaParaXmlDanfeMon);
            this.tabPage8.Controls.Add(this.label17);
            this.tabPage8.Controls.Add(this.label15);
            this.tabPage8.Controls.Add(this.tbPastaConfigUniDanfe);
            this.tabPage8.Controls.Add(this.label16);
            this.tabPage8.Controls.Add(this.tbPastaExeUniDanfe);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(596, 312);
            this.tabPage8.TabIndex = 3;
            this.tabPage8.Text = "DANFe";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // Configuracao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(611, 451);
            this.Controls.Add(this.tabControl2);
            this.Controls.Add(this.toolStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Configuracao";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Configurações";
            this.Load += new System.EventHandler(this.Configuracao_Load);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Configuracao_FormClosed);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.udDiasLimpeza)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudPorta)).EndInit();
            this.tabControl2.ResumeLayout(false);
            this.tabPageGeral.ResumeLayout(false);
            this.tabControl4.ResumeLayout(false);
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.tabPageEmpresa.ResumeLayout(false);
            this.tabPageEmpresa.PerformLayout();
            this.tabControl3.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_PastaEnvioXML;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_PastaRetornoXML;
        private System.Windows.Forms.ComboBox comboBox_UF;
        private System.Windows.Forms.ComboBox comboBox_Ambiente;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.Button button_selectxmlenvio;
        private System.Windows.Forms.Button button_SelectPastaXmlRetorno;
        private System.Windows.Forms.ToolStripButton toolStripButton_salvar;
        private System.Windows.Forms.ToolStripButton toolStripButton_fechar;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog_xmlenvio;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog_xmlretorno;
        private System.Windows.Forms.TextBox textBox_dadoscertificado;
        private System.Windows.Forms.Button button_selecionar_certificado;
        private System.Windows.Forms.TextBox textBox_PastaEnviados;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button_SelectPastaXmlEnviado;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog_xmlenviado;
        private System.Windows.Forms.Button button_SelectPastaXmlErro;
        private System.Windows.Forms.TextBox textBox_PastaXmlErro;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog_xmlerro;
        private System.Windows.Forms.ComboBox comboBox_tpEmis;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button_SelectPastaBackup;
        private System.Windows.Forms.TextBox textBox_PastaBackup;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog_backup;
        private System.Windows.Forms.Button btnSelectPastaLote;
        private System.Windows.Forms.TextBox tbPastaLote;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog_xmlenviolote;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button button_SelectPastaValidar;
        private System.Windows.Forms.TextBox tbPastaValidar;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog_Validar;
        private System.Windows.Forms.CheckBox checkBoxRetornoNFETxt;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label lblSenha;
        private System.Windows.Forms.Label lblPorta;
        private System.Windows.Forms.Label lblUsuario;
        private System.Windows.Forms.CheckBox cbProxy;
        private System.Windows.Forms.TextBox tbSenha;
        private System.Windows.Forms.TextBox tbUsuario;
        private System.Windows.Forms.NumericUpDown nudPorta;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cboDiretorioSalvarComo;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown udDiasLimpeza;
        private System.Windows.Forms.TextBox tbServidor;
        private System.Windows.Forms.Label lblServidor;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tbTextoDANFE;
        private System.Windows.Forms.Button button_SelectPastaExeUniDanfe;
        private System.Windows.Forms.TextBox tbPastaExeUniDanfe;
        private System.Windows.Forms.Button button_SelectPastaConfUniDanfe;
        private System.Windows.Forms.TextBox tbPastaConfigUniDanfe;
        private System.Windows.Forms.Button btnSelectPastaParaXmlDanfeMon;
        private System.Windows.Forms.TextBox tbPastaXmlParaDanfeMon;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.CheckBox cbDanfeMonProcNfe;
        private System.Windows.Forms.CheckBox cbDanfeMonNfe;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPageGeral;
        private System.Windows.Forms.TabPage tabPageEmpresa;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.ComboBox cbEmpresa;
        private System.Windows.Forms.Label label19;
    }
}