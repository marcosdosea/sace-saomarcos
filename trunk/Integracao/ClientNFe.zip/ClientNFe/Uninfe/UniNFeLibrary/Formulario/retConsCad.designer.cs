﻿namespace UniNFeLibrary.Formulario
{
    partial class retConsCad
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCNPJ_CPF = new System.Windows.Forms.TextBox();
            this.txtxNome = new System.Windows.Forms.TextBox();
            this.txtxEnder = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtxBairro = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtnro = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtxFant = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtxIE = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtxCpl = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtxMun = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtUF = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtCEP = new System.Windows.Forms.MaskedTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtdBaixa = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtdUltSit = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtdIniAtiv = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtxRegApur = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtCNAE = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtIEUnica = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtIEAtual = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtcSit = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtCNPJ_CPF
            // 
            this.txtCNPJ_CPF.Location = new System.Drawing.Point(77, 3);
            this.txtCNPJ_CPF.Name = "txtCNPJ_CPF";
            this.txtCNPJ_CPF.ReadOnly = true;
            this.txtCNPJ_CPF.Size = new System.Drawing.Size(142, 20);
            this.txtCNPJ_CPF.TabIndex = 0;
            // 
            // txtxNome
            // 
            this.txtxNome.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtxNome.Location = new System.Drawing.Point(77, 29);
            this.txtxNome.Name = "txtxNome";
            this.txtxNome.ReadOnly = true;
            this.txtxNome.Size = new System.Drawing.Size(487, 20);
            this.txtxNome.TabIndex = 1;
            // 
            // txtxEnder
            // 
            this.txtxEnder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtxEnder.Location = new System.Drawing.Point(77, 81);
            this.txtxEnder.Name = "txtxEnder";
            this.txtxEnder.ReadOnly = true;
            this.txtxEnder.Size = new System.Drawing.Size(487, 20);
            this.txtxEnder.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "XXXXXXXX";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Nome";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Endereço";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 133);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Bairro";
            // 
            // txtxBairro
            // 
            this.txtxBairro.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtxBairro.Location = new System.Drawing.Point(77, 133);
            this.txtxBairro.Name = "txtxBairro";
            this.txtxBairro.ReadOnly = true;
            this.txtxBairro.Size = new System.Drawing.Size(487, 20);
            this.txtxBairro.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 107);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Número";
            // 
            // txtnro
            // 
            this.txtnro.Location = new System.Drawing.Point(77, 107);
            this.txtnro.Name = "txtnro";
            this.txtnro.ReadOnly = true;
            this.txtnro.Size = new System.Drawing.Size(177, 20);
            this.txtnro.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 55);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Fantasia";
            // 
            // txtxFant
            // 
            this.txtxFant.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtxFant.Location = new System.Drawing.Point(77, 55);
            this.txtxFant.Name = "txtxFant";
            this.txtxFant.ReadOnly = true;
            this.txtxFant.Size = new System.Drawing.Size(487, 20);
            this.txtxFant.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(332, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "I.E.";
            // 
            // txtxIE
            // 
            this.txtxIE.Location = new System.Drawing.Point(361, 3);
            this.txtxIE.Name = "txtxIE";
            this.txtxIE.ReadOnly = true;
            this.txtxIE.Size = new System.Drawing.Size(144, 20);
            this.txtxIE.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(287, 107);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Complemento";
            // 
            // txtxCpl
            // 
            this.txtxCpl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtxCpl.Location = new System.Drawing.Point(361, 107);
            this.txtxCpl.Name = "txtxCpl";
            this.txtxCpl.ReadOnly = true;
            this.txtxCpl.Size = new System.Drawing.Size(203, 20);
            this.txtxCpl.TabIndex = 14;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 159);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Cidade";
            // 
            // txtxMun
            // 
            this.txtxMun.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtxMun.Location = new System.Drawing.Point(77, 159);
            this.txtxMun.Name = "txtxMun";
            this.txtxMun.ReadOnly = true;
            this.txtxMun.Size = new System.Drawing.Size(487, 20);
            this.txtxMun.TabIndex = 16;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 185);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 13);
            this.label10.TabIndex = 19;
            this.label10.Text = "Estado";
            // 
            // txtUF
            // 
            this.txtUF.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtUF.Location = new System.Drawing.Point(77, 185);
            this.txtUF.Name = "txtUF";
            this.txtUF.ReadOnly = true;
            this.txtUF.Size = new System.Drawing.Size(50, 20);
            this.txtUF.TabIndex = 18;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(143, 185);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(28, 13);
            this.label11.TabIndex = 21;
            this.label11.Text = "CEP";
            // 
            // txtCEP
            // 
            this.txtCEP.Location = new System.Drawing.Point(177, 185);
            this.txtCEP.Mask = "00000-999";
            this.txtCEP.Name = "txtCEP";
            this.txtCEP.ReadOnly = true;
            this.txtCEP.Size = new System.Drawing.Size(78, 20);
            this.txtCEP.TabIndex = 22;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 211);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(141, 13);
            this.label12.TabIndex = 24;
            this.label12.Text = "Data de ocorrência da baixa";
            // 
            // txtdBaixa
            // 
            this.txtdBaixa.Location = new System.Drawing.Point(257, 211);
            this.txtdBaixa.Name = "txtdBaixa";
            this.txtdBaixa.ReadOnly = true;
            this.txtdBaixa.Size = new System.Drawing.Size(101, 20);
            this.txtdBaixa.TabIndex = 23;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 237);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(239, 13);
            this.label13.TabIndex = 26;
            this.label13.Text = "Data da última modificação da situação cadastral";
            // 
            // txtdUltSit
            // 
            this.txtdUltSit.Location = new System.Drawing.Point(257, 237);
            this.txtdUltSit.Name = "txtdUltSit";
            this.txtdUltSit.ReadOnly = true;
            this.txtdUltSit.Size = new System.Drawing.Size(101, 20);
            this.txtdUltSit.TabIndex = 25;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 263);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(136, 13);
            this.label14.TabIndex = 28;
            this.label14.Text = "Data de Início da atividade";
            // 
            // txtdIniAtiv
            // 
            this.txtdIniAtiv.Location = new System.Drawing.Point(257, 263);
            this.txtdIniAtiv.Name = "txtdIniAtiv";
            this.txtdIniAtiv.ReadOnly = true;
            this.txtdIniAtiv.Size = new System.Drawing.Size(101, 20);
            this.txtdIniAtiv.TabIndex = 27;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 289);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(151, 13);
            this.label15.TabIndex = 30;
            this.label15.Text = "Regime de Apuração do ICMS";
            // 
            // txtxRegApur
            // 
            this.txtxRegApur.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtxRegApur.Location = new System.Drawing.Point(160, 289);
            this.txtxRegApur.Name = "txtxRegApur";
            this.txtxRegApur.ReadOnly = true;
            this.txtxRegApur.Size = new System.Drawing.Size(404, 20);
            this.txtxRegApur.TabIndex = 29;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(444, 211);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(36, 13);
            this.label16.TabIndex = 32;
            this.label16.Text = "CNAE";
            // 
            // txtCNAE
            // 
            this.txtCNAE.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCNAE.Location = new System.Drawing.Point(486, 211);
            this.txtCNAE.Name = "txtCNAE";
            this.txtCNAE.ReadOnly = true;
            this.txtCNAE.Size = new System.Drawing.Size(78, 20);
            this.txtCNAE.TabIndex = 31;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(3, 315);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(54, 13);
            this.label17.TabIndex = 34;
            this.label17.Text = "I.E. Unica";
            // 
            // txtIEUnica
            // 
            this.txtIEUnica.Location = new System.Drawing.Point(160, 315);
            this.txtIEUnica.Name = "txtIEUnica";
            this.txtIEUnica.ReadOnly = true;
            this.txtIEUnica.Size = new System.Drawing.Size(144, 20);
            this.txtIEUnica.TabIndex = 33;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(364, 315);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(50, 13);
            this.label18.TabIndex = 36;
            this.label18.Text = "I.E. Atual";
            // 
            // txtIEAtual
            // 
            this.txtIEAtual.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtIEAtual.Location = new System.Drawing.Point(420, 315);
            this.txtIEAtual.Name = "txtIEAtual";
            this.txtIEAtual.ReadOnly = true;
            this.txtIEAtual.Size = new System.Drawing.Size(144, 20);
            this.txtIEAtual.TabIndex = 35;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(3, 341);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 13);
            this.label19.TabIndex = 38;
            this.label19.Text = "Observações";
            // 
            // txtcSit
            // 
            this.txtcSit.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtcSit.Location = new System.Drawing.Point(77, 341);
            this.txtcSit.Name = "txtcSit";
            this.txtcSit.ReadOnly = true;
            this.txtcSit.Size = new System.Drawing.Size(487, 20);
            this.txtcSit.TabIndex = 37;
            // 
            // retConsCad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label19);
            this.Controls.Add(this.txtcSit);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.txtIEAtual);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txtIEUnica);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.txtCNAE);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txtxRegApur);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtdIniAtiv);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtdUltSit);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtdBaixa);
            this.Controls.Add(this.txtCEP);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtUF);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtxMun);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtxCpl);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtxIE);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtxFant);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtnro);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtxBairro);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtxEnder);
            this.Controls.Add(this.txtxNome);
            this.Controls.Add(this.txtCNPJ_CPF);
            this.Name = "retConsCad";
            this.Size = new System.Drawing.Size(572, 368);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCNPJ_CPF;
        private System.Windows.Forms.TextBox txtxNome;
        private System.Windows.Forms.TextBox txtxEnder;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtxBairro;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtnro;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtxFant;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtxIE;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtxCpl;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtxMun;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtUF;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.MaskedTextBox txtCEP;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtdBaixa;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtdUltSit;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtdIniAtiv;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtxRegApur;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtCNAE;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtIEUnica;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtIEAtual;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtcSit;
    }
}
