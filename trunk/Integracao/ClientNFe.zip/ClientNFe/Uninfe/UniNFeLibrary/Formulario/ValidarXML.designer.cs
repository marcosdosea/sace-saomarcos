﻿namespace UniNFeLibrary.Formulario
{
    partial class ValidarXML
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ValidarXML));
            this.textBox_arqxml = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox_resultado = new System.Windows.Forms.TextBox();
            this.textBox_tipoarq = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.openFileDialog_arqxml = new System.Windows.Forms.OpenFileDialog();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton_validar = new System.Windows.Forms.ToolStripButton();
            this.lblEmpresa = new System.Windows.Forms.Label();
            this.cbEmpresa = new System.Windows.Forms.ComboBox();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox_arqxml
            // 
            this.textBox_arqxml.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.textBox_arqxml.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.FileSystem;
            this.textBox_arqxml.Location = new System.Drawing.Point(8, 102);
            this.textBox_arqxml.Name = "textBox_arqxml";
            this.textBox_arqxml.Size = new System.Drawing.Size(579, 20);
            this.textBox_arqxml.TabIndex = 0;
            this.textBox_arqxml.TextChanged += new System.EventHandler(this.textBox_arqxml_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Arquivo XML a ser validado:";
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(593, 105);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(27, 24);
            this.button1.TabIndex = 2;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox_resultado
            // 
            this.textBox_resultado.Location = new System.Drawing.Point(8, 193);
            this.textBox_resultado.Multiline = true;
            this.textBox_resultado.Name = "textBox_resultado";
            this.textBox_resultado.ReadOnly = true;
            this.textBox_resultado.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_resultado.Size = new System.Drawing.Size(612, 208);
            this.textBox_resultado.TabIndex = 3;
            // 
            // textBox_tipoarq
            // 
            this.textBox_tipoarq.Location = new System.Drawing.Point(8, 146);
            this.textBox_tipoarq.Name = "textBox_tipoarq";
            this.textBox_tipoarq.ReadOnly = true;
            this.textBox_tipoarq.Size = new System.Drawing.Size(612, 20);
            this.textBox_tipoarq.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Tipo do arquivo:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(122, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Resultado da validação:";
            // 
            // openFileDialog_arqxml
            // 
            this.openFileDialog_arqxml.FileName = "openFileDialog1";
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton_validar});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(627, 39);
            this.toolStrip1.TabIndex = 7;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton_validar
            // 
            this.toolStripButton_validar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton_validar.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton_validar.Image")));
            this.toolStripButton_validar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton_validar.Name = "toolStripButton_validar";
            this.toolStripButton_validar.Size = new System.Drawing.Size(36, 36);
            this.toolStripButton_validar.Text = "toolStripButton1";
            this.toolStripButton_validar.ToolTipText = "Validar o XML";
            this.toolStripButton_validar.Click += new System.EventHandler(this.toolStripButton_validar_Click);
            // 
            // lblEmpresa
            // 
            this.lblEmpresa.AutoSize = true;
            this.lblEmpresa.Location = new System.Drawing.Point(5, 39);
            this.lblEmpresa.Name = "lblEmpresa";
            this.lblEmpresa.Size = new System.Drawing.Size(307, 13);
            this.lblEmpresa.TabIndex = 958;
            this.lblEmpresa.Text = "Selecione a empresa do certificado a ser utilizado na validação:";
            // 
            // cbEmpresa
            // 
            this.cbEmpresa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbEmpresa.FormattingEnabled = true;
            this.cbEmpresa.Location = new System.Drawing.Point(8, 57);
            this.cbEmpresa.Name = "cbEmpresa";
            this.cbEmpresa.Size = new System.Drawing.Size(579, 21);
            this.cbEmpresa.TabIndex = 959;
            this.cbEmpresa.SelectedIndexChanged += new System.EventHandler(this.cbEmpresa_SelectedIndexChanged);
            // 
            // ValidarXML
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(627, 407);
            this.Controls.Add(this.lblEmpresa);
            this.Controls.Add(this.cbEmpresa);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_tipoarq);
            this.Controls.Add(this.textBox_resultado);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox_arqxml);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ValidarXML";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Validar os arquivos XML";
            this.Load += new System.EventHandler(this.ValidarXML_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_arqxml;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox_resultado;
        private System.Windows.Forms.TextBox textBox_tipoarq;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.OpenFileDialog openFileDialog_arqxml;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton_validar;
        private System.Windows.Forms.Label lblEmpresa;
        private System.Windows.Forms.ComboBox cbEmpresa;
    }
}