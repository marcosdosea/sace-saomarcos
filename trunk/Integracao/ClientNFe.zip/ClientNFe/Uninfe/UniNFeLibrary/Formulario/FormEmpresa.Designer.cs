﻿namespace UniNFeLibrary.Formulario
{
    partial class FormEmpresa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormEmpresa));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbtnSalvar = new System.Windows.Forms.ToolStripButton();
            this.tsbtnFechar = new System.Windows.Forms.ToolStripButton();
            this.gridEmpresa = new System.Windows.Forms.DataGridView();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridEmpresa)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbtnSalvar,
            this.tsbtnFechar});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(588, 39);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbtnSalvar
            // 
            this.tsbtnSalvar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbtnSalvar.Image = global::UniNFeLibrary.Properties.Resources.filesave;
            this.tsbtnSalvar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnSalvar.Name = "tsbtnSalvar";
            this.tsbtnSalvar.Size = new System.Drawing.Size(36, 36);
            this.tsbtnSalvar.Text = "toolStripButton1";
            this.tsbtnSalvar.ToolTipText = "Salvar as alterações e fechar a tela";
            this.tsbtnSalvar.Click += new System.EventHandler(this.tsbtnSalvar_Click);
            // 
            // tsbtnFechar
            // 
            this.tsbtnFechar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbtnFechar.Image = global::UniNFeLibrary.Properties.Resources.fileclose;
            this.tsbtnFechar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbtnFechar.Name = "tsbtnFechar";
            this.tsbtnFechar.Size = new System.Drawing.Size(36, 36);
            this.tsbtnFechar.Text = "toolStripButton2";
            this.tsbtnFechar.ToolTipText = "Fechar a tela sem salvar as alterações";
            this.tsbtnFechar.Click += new System.EventHandler(this.tsbtnFechar_Click);
            // 
            // gridEmpresa
            // 
            this.gridEmpresa.AllowUserToResizeRows = false;
            this.gridEmpresa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridEmpresa.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridEmpresa.Location = new System.Drawing.Point(0, 39);
            this.gridEmpresa.Name = "gridEmpresa";
            this.gridEmpresa.Size = new System.Drawing.Size(588, 365);
            this.gridEmpresa.TabIndex = 1;
            this.gridEmpresa.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.gridEmpresa_CellBeginEdit);
            this.gridEmpresa.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.gridEmpresa_CellValidating);
            this.gridEmpresa.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridEmpresa_CellEndEdit);
            // 
            // FormEmpresa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(588, 404);
            this.Controls.Add(this.gridEmpresa);
            this.Controls.Add(this.toolStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FormEmpresa";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastro de empresas";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormEmpresa_FormClosed);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridEmpresa)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbtnSalvar;
        private System.Windows.Forms.ToolStripButton tsbtnFechar;
        private System.Windows.Forms.DataGridView gridEmpresa;
    }
}