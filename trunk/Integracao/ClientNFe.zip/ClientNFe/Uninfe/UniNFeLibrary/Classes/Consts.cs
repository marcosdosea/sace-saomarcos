﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniNFeLibrary
{
    public class UniNFeConsts
    {
        public static string[] tpEmissao = 
            { 
                "", 
                "Normal", 
                "Contingência com formulário de segurança (FS)", 
                "Contingência com SCAN do Ambiente Nacional", 
                "Contingência com DPEC", 
                "Contingência com formulário de segurança (FS-DA)" 
            };
    }
}
