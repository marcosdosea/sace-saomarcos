﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniNFeLibrary
{
    /// <summary>
    /// Executar as thread´s dos serviços do UniNFe e NFe conforme necessário
    /// </summary>
    /// <remarks>
    /// Autor: Wandrey Mundin Ferreira
    /// Data: 04/04/2011
    /// </remarks>
    class ExecutaThread
    {
        #region Construtores
        public ExecutaThread()
        {

        }
        #endregion
    }
}
