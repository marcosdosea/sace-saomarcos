﻿namespace UniNFeLibrary
{
    public class UF
    {
        public string Uf { get; set; }
        public int Id { get; set; }
        public string Nome { get; set; }
    }
}