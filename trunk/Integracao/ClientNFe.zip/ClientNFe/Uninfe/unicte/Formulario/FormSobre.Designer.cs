﻿namespace unicte.Formulario
{
    partial class FormSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSobre));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_licenca = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox_DataUltimaModificacao = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_versao = new System.Windows.Forms.TextBox();
            this.btnManualUniCTe = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(165, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "UniCTe";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(170, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(351, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Monitor de Conhecimentos de Transportes Eletrônicos";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(222, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Desenvolvido por:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(222, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Unimake Softwares";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(222, 97);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(109, 13);
            this.linkLabel1.TabIndex = 5;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "www.unimake.com.br";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(222, 135);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(108, 13);
            this.linkLabel2.TabIndex = 6;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "nfe@unimake.com.br";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Location = new System.Drawing.Point(222, 122);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(143, 13);
            this.linkLabel3.TabIndex = 7;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "www.unimake.com.br/uninfe";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 205);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Autorização de utilização:";
            // 
            // textBox_licenca
            // 
            this.textBox_licenca.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_licenca.Location = new System.Drawing.Point(13, 223);
            this.textBox_licenca.Multiline = true;
            this.textBox_licenca.Name = "textBox_licenca";
            this.textBox_licenca.ReadOnly = true;
            this.textBox_licenca.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox_licenca.Size = new System.Drawing.Size(534, 138);
            this.textBox_licenca.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 161);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Data da última modificação:";
            // 
            // textBox_DataUltimaModificacao
            // 
            this.textBox_DataUltimaModificacao.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_DataUltimaModificacao.Location = new System.Drawing.Point(13, 179);
            this.textBox_DataUltimaModificacao.Name = "textBox_DataUltimaModificacao";
            this.textBox_DataUltimaModificacao.ReadOnly = true;
            this.textBox_DataUltimaModificacao.Size = new System.Drawing.Size(169, 20);
            this.textBox_DataUltimaModificacao.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(222, 161);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Versão:";
            // 
            // textBox_versao
            // 
            this.textBox_versao.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_versao.Location = new System.Drawing.Point(225, 178);
            this.textBox_versao.Name = "textBox_versao";
            this.textBox_versao.ReadOnly = true;
            this.textBox_versao.Size = new System.Drawing.Size(221, 20);
            this.textBox_versao.TabIndex = 14;
            // 
            // btnManualUniCTe
            // 
            this.btnManualUniCTe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManualUniCTe.Image = global::unicte.Properties.Resources.pdf3;
            this.btnManualUniCTe.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnManualUniCTe.Location = new System.Drawing.Point(472, 142);
            this.btnManualUniCTe.Name = "btnManualUniCTe";
            this.btnManualUniCTe.Size = new System.Drawing.Size(75, 75);
            this.btnManualUniCTe.TabIndex = 15;
            this.btnManualUniCTe.Text = "Manual";
            this.btnManualUniCTe.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnManualUniCTe.UseVisualStyleBackColor = true;
            this.btnManualUniCTe.Click += new System.EventHandler(this.btnManualUniCTe_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::unicte.Properties.Resources.unicte128;
            this.pictureBox1.Location = new System.Drawing.Point(3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 128);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.WaitOnLoad = true;
            // 
            // FormSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(559, 373);
            this.Controls.Add(this.btnManualUniCTe);
            this.Controls.Add(this.textBox_versao);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox_DataUltimaModificacao);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBox_licenca);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.linkLabel3);
            this.Controls.Add(this.linkLabel2);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FormSobre";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sobre";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_licenca;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox_DataUltimaModificacao;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox_versao;
        private System.Windows.Forms.Button btnManualUniCTe;

    }
}