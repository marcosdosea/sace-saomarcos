﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniNFeTXT
{
    public class Retirada
    {
        public string CNPJ;
        public string xLgr;
        public string nro;
        public string xCpl;
        public string xBairro;
        public int cMun;
        public string xMun;
        public string UF;
    }
}
