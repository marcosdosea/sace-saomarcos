﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniNFeTXT
{
    public class Avulsa
    {
        public string CNPJ;
        public string xOrgao;
        public string matr;
        public string xAgente;
        public string fone;
        public string UF;
        public string nDAR;
        public DateTime dEmi;
        public double vDAR;
        public string repEmi;
        public DateTime dPag;
    }
}
