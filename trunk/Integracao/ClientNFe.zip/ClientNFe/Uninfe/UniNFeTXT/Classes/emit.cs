﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UniNFeTXT
{
    public class enderEmit
    {
        public string xLgr;
        public string nro;
        public string xCpl;
        public string xBairro;
        public int cMun;
        public string xMun;
        public string UF;
        public int CEP;
        public int cPais;
        public string xPais;
        public string fone;
    }

    public class Emit
    {
        public string CNPJCPF;
        public string xNome;
        public string xFant;
        public enderEmit enderEmit;
        public string IE;
        public string IEST;
        public string IM;
        public string CNAE;

        public Emit()
        {
            enderEmit = new enderEmit();
        }
    }
}
