﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NFeService.Model
{
    public class NFeCabecalhoDTO
    {
        public int? id { get; set; }
        public int? idEmpresa { get; set; }
        public string codigoNumerico { get; set; }
        public string naturezaOperacao { get; set; }
        public string indicadorFormaPagamento { get; set; }
        public string codigoModelo { get; set; }
        public string serie { get; set; }
        public string numero { get; set; }
        public DateTime? dataEmissao { get; set; }
        public DateTime? dataEntradaSaida { get; set; }
        public string horaEntradaSaida { get; set; }
        public string tipoOperacao { get; set; }
        public int? codigoMunicipio { get; set; }
        public string formatoImpressaoDANFE { get; set; }
        public string tipoEmissao { get; set; }
        public string chaveAcesso { get; set; }
        public string digitoChaveAcesso { get; set; }
        public string ambiente { get; set; }
        public string finalidadeEmissao { get; set; }
        public string processoEmissao { get; set; }
        public int? versaoProcessoEmissao { get; set; }
        public decimal? baseCalculoICMS { get; set; }
        public decimal? valorICMS { get; set; }
        public decimal? baseCalculoICMS_ST { get; set; }
        public decimal? valorICMS_ST { get; set; }
        public decimal? valorTotalProdutos { get; set; }
        public decimal? valorFrete { get; set; }
        public decimal? valorSeguro { get; set; }
        public decimal? valorDesconto { get; set; }
        public decimal? valorImpostoImportacao { get; set; }
        public decimal? valorIPI { get; set; }
        public decimal? valorPIS { get; set; }
        public decimal? valorCOFINS { get; set; }
        public decimal? valorDespesasAcessorias { get; set; }
        public decimal? valorTotal { get; set; }
        public decimal? valorServicos { get; set; }
        public decimal? baseCalculoISSQN { get; set; }
        public decimal? valorISSQN { get; set; }
        public decimal? valorPIS_ISSQN { get; set; }
        public decimal? valorCOFINS_ISSQN { get; set; }
        public decimal? valorRetidoPIS { get; set; }
        public decimal? valorRetidoCOFINS { get; set; }
        public decimal? valorRetidoCSLL { get; set; }
        public decimal? baseCalculoIRRF { get; set; }
        public decimal? valorRetidoIRRF { get; set; }
        public decimal? baseCalculoPrevidencia { get; set; }
        public decimal? valorRetidoPrevidencia { get; set; }
        public string ufEmbarque { get; set; }
        public string localEmbarque { get; set; }
        public string notaEmpenho { get; set; }
        public string pedido { get; set; }
        public string ISSretido { get; set; }
        public string informacoesAddFisco { get; set; }
        public string informacoesAddContribuinte { get; set; }
        public string informacoesComplementares { get; set; }
        public string statusNota { get; set; }

        public IList<NFeDetalheDTO> listaDetalhe { get; set; }
        public IList<NFeCupomFiscalDTO> listaCupomFiscal { get; set; }
        public NFeDestinatarioDTO destinatario { get; set; }
        public NFeLocalEntregaDTO localEntrega { get; set; }
        public NFeLocalRetiradaDTO localRetirada { get; set; }
        public NFeTransporteDTO transporte { get; set; }
        public NFeFaturaDTO fatura { get; set; }
        public NFeEmitenteDTO emitente { get; set; }

    }
}