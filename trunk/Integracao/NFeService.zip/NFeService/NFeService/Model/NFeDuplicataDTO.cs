﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NFeService.Model
{
    public class NFeDuplicataDTO
    {
        public int? id { get; set; }
        public int? idNFeFatura { get; set; }
        public string numero { get; set; }
        public DateTime? dataVencimento { get; set; }
        public decimal? valor { get; set; }
    }
}