﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NFeService.Model
{
    public class NFeDestinatarioDTO
    {
        public int? id { get; set; }
        public int? idNFeCabecalho { get; set; }
        public string cpfCnpj { get; set; }
        public string razaoSocial { get; set; }
        public string fantasia { get; set; }
        public string logradouro { get; set; }
        public string numero { get; set; }
        public string complemento { get; set; }
        public string bairro { get; set; }
        public int codigoMunicipio { get; set; }
        public string nomeMunicipio { get; set; }
        public string uf { get; set; }
        public string cep { get; set; }
        public int codigoPais { get; set; }
        public string nomePais { get; set; }
        public string telefone { get; set; }
        public string ie { get; set; }
        public string iest { get; set; }
        public string im { get; set; }
        public string cnae { get; set; }
        public int crt { get; set; }
        public string suframa { get; set; }
        public string email { get; set; }

    }
}