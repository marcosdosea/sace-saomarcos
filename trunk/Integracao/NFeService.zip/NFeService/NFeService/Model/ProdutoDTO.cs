﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace NFeService.Model
{
    public class ProdutoDTO
    {
        public int? id { get; set; }
        public TributacaoEstadualDTO tributacaoEstadual { get; set; }
        public UnidadeDTO unidade { get; set; }
        public NcmDTO ncm { get; set; }
        public int? idBaseCalculoReduzida { get; set; }
        public int? idImpostoST_UF { get; set; }
        public int? idEmpresa { get; set; }
        public int? idMarcaProduto { get; set; }
        public int? idTipoItemSPED { get; set; }
        public int? idNCM { get; set; }
        public int? idSubGrupo { get; set; }
        public int? idUnidade { get; set; }
        public string gtin { get; set; }
        public string codigoInterno { get; set; }
        public string nome { get; set; }
        public string descricao { get; set; }
        public string descricaoPDV { get; set; }
        public decimal? valorCompra{ get; set; }
        public decimal? valorVenda { get; set; }
        public decimal? precoVendaMinimo { get; set; }
        public decimal? precoSugerido { get; set; }
        public decimal? custoMedioLiquido { get; set; }
        public decimal? precoLucroZero { get; set; }
        public decimal? precoLucroMinimo { get; set; }
        public decimal? precoLucroMaximo { get; set; }
        public decimal? markup { get; set; }
        public decimal? quantidadeEstoque { get; set; }
        public decimal? estoqueMinimo { get; set; }
        public decimal? estoqueMaximo { get; set; }
        public string excluido { get; set; }
        public string inativo { get; set; }
        public DateTime? dataCadastro { get; set; }
        public string imagem { get; set; }
        public string exTIPI { get; set; }
        public string codigoLST { get; set; }
        public string classeABC { get; set; }
        public string iat { get; set; }
        public string ippt { get; set; }
    }
}