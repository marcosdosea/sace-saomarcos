﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NFeService.Model
{
    public class NFeFaturaDTO
    {
        public int? id { get; set; }
        public int? idNFeCabecalho { get; set; }
        public string numero { get; set; }
        public decimal? valorOriginal { get; set; }
        public decimal? valorDesconto { get; set; }
        public decimal? valorLiquido { get; set; }

        public IList<NFeDuplicataDTO> listaDuplicata { get; set; }

    }
}