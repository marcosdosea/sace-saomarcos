﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NFeService.Model
{
    public class NFeDetalheDTO
    {
        public int? id { get; set; }
        public int? idLoteProduto { get; set; }
        public int? idNFeCabecalho { get; set; }
        public int? idProduto { get; set; }
        public int? numeroItem { get; set; }
        public string codigoProduto { get; set; }
        public string gtin { get; set; }
        public string nomeProduto { get; set; }
        public string ncm { get; set; }
        public int? exTIPI { get; set; }
        public int? cfop { get; set; }
        public string unidadeComercial { get; set; }
        public decimal? quantidadeComercial { get; set; }
        public decimal? valorUnitarioComercial { get; set; }
        public decimal? valorBrutoProdutos { get; set; }
        public string gtinUnidadeTributavel { get; set; }
        public string unidadeTributavel { get; set; }
        public decimal? quantidadeTributavel { get; set; }
        public decimal? valorUnitarioTributacao { get; set; }
        public decimal? valorFrete { get; set; }
        public decimal? valorSeguro { get; set; }
        public decimal? valorDesconto { get; set; }
        public decimal? valorOutrasDespesas { get; set; }
        public string entraTotal { get; set; }
        public string origemMercadoria { get; set; }
        public string cstICMS { get; set; }
        public string csosn { get; set; }
        public string modalidadeBC_ICMS { get; set; }
        public decimal? taxaReducaoBC_ICMS { get; set; }
        public decimal? baseCalculoICMS { get; set; }
        public decimal? aliquotaICMS { get; set; }
        public decimal? valorICMS { get; set; }
        public string motivoDesoneracaoICMS { get; set; }
        public string modalidadeBC_ICMS_ST { get; set; }
        public decimal? percentualMVA_ICMS_ST { get; set; }
        public decimal? reducaoBC_ICMS_ST { get; set; }
        public decimal? baseCalculoICMS_ST { get; set; }
        public decimal? aliquotaICMS_ST { get; set; }
        public decimal? valorICMS_ST { get; set; }
        public decimal? valorBC_ICMS_ST_Retido { get; set; }
        public decimal? valorICMS_ST_Retido { get; set; }
        public decimal? aliquotaCreditoICMS_SN { get; set; }
        public decimal? valorCreditoICMS_SN { get; set; }
        public string enquadramentoIPI { get; set; }
        public string cnpjProdutor { get; set; }
        public string codigoSeloIPI { get; set; }
        public int? quantidadeSeloIPI { get; set; }
        public string enquadramentoLegalIPI { get; set; }
        public string cstIPI { get; set; }
        public decimal? baseCalculoIPI { get; set; }
        public decimal? aliquotaIPI { get; set; }
        public decimal? valorIPI { get; set; }
        public decimal? valorBC_II { get; set; }
        public decimal? valorDespesasAduaneiras { get; set; }
        public decimal? valorImpostoImportacao { get; set; }
        public decimal? valorIOF { get; set; }
        public string cstPIS { get; set; }
        public decimal? valorBaseCalculoPIS { get; set; }
        public decimal? aliquotaPIS_Percentual { get; set; }
        public decimal? aliquotaPIS_Reais { get; set; }
        public decimal? valorPIS { get; set; }
        public string cstCOFINS { get; set; }
        public decimal? baseCalculoCOFINS { get; set; }
        public decimal? aliquotaCOFINS_Percentual { get; set; }
        public decimal? aliquotaCOFINS_Reais { get; set; }
        public decimal? valorCOFINS { get; set; }
        public decimal? baseCalculoISSQN { get; set; }
        public decimal? aliquotaISSQN { get; set; }
        public decimal? valorISSQN { get; set; }
        public int? municipioISSQN { get; set; }
        public int? itemListaServicos { get; set; }
        public string tributacaoISSQN { get; set; }
        public decimal? valorSubtotal { get; set; }
        public decimal? valorTotal { get; set; }
        public string informacoesAdicionais { get; set; }

    }
}