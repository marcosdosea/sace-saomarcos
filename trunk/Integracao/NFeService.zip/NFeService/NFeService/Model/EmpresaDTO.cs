﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NFeService.Model
{
    public class EmpresaDTO
    {
        public int? id { get; set; }
        public int? idCNAE { get; set; }
        public int? idEmpresa { get; set; }
        public string razaoSocial { get; set; }
        public string nomeFantasia { get; set; }
        public string cnpj { get; set; }
        public string inscricaoEstadual { get; set; }
        public string inscricaoEstadualST { get; set; }
        public string inscricaoMunicipal { get; set; }
        public string tipo { get; set; }
        public DateTime? dataCadastro { get; set; }
        public string suframa { get; set; }
        public string email { get; set; }
        public string imagemLogotipo { get; set; }
        public int? crt { get; set; }
        public string tipoRegime { get; set; }
        public decimal? aliquotaPIS { get; set; }
        public decimal? aliquotaCOFINS { get; set; }
        public string contato { get; set; }
        public int? codigoIBGECidade { get; set; }
        public int? codigoIBGE_UF { get; set; }

        public EnderecoDTO endereco { get; set; }
    }
}