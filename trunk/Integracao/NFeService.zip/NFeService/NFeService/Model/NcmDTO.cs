﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NFeService.Model
{
    public class NcmDTO
    {
        public int? id { get; set; }
        public string ncmCompleto { get; set; }
    }
}