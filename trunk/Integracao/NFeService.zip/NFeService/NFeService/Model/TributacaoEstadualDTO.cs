﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NFeService.Model
{
    public class TributacaoEstadualDTO
    {
        public int? id { get; set; }
        public int? idEmpresa { get; set; }
        public string descricao { get; set; }
        public DateTime? dataCadastro { get; set; }
        public DateTime? dataAlteracao { get; set; }
        public decimal? taxaISSQN { get; set; }
        public decimal? taxaICMS { get; set; }
        public int? cfopFora { get; set; }
        public int? cfopDentro { get; set; }
        public string cstA_ICMS { get; set; }
        public string cstB_ICMS { get; set; }
        public string cstECF { get; set; }
        public string csosn { get; set; }

    }
}