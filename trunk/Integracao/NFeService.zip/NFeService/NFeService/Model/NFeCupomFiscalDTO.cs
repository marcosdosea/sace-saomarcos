﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NFeService.Model
{
    public class NFeCupomFiscalDTO
    {
        public int? id { get; set; }
        public int? idNFeCabecalho { get; set; }
        public string modeloDocumentoFiscal { get; set; }
        public DateTime? dataEmissaoCupom { get; set; }
        public int? numeroOrdemECF { get; set; }
        public int? coo { get; set; }
        public int? numeroCaixa { get; set; }
        public string numeroSerieECF { get; set; }

    }
}