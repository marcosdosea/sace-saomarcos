﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NFeService.Model
{
    public class NFeTransporteDTO
    {
        public int? id { get; set; }
        public int? idNFeCabecalho { get; set; }
        public string modalidadeFrete { get; set; }
        public string cpfCnpj { get; set; }
        public string nome { get; set; }
        public string inscricaoEstadual { get; set; }
        public string endereco { get; set; }
        public string nomeMunicipio { get; set; }
        public string uf { get; set; }
        public decimal? valorServico { get; set; }
        public decimal? baseCalculoRetencaoICMS { get; set; }
        public decimal? aliquotaRetencaoICMS { get; set; }
        public decimal? valorICMS_Retido { get; set; }
        public int? cfop { get; set; }
        public int? municipio { get; set; }
        public string placaVeiculo { get; set; }
        public string ufVeiculo { get; set; }
        public string rntcVeiculo { get; set; }
        public string placaReboque { get; set; }
        public string ufReboque { get; set; }
        public string rntcReboque { get; set; }
        public string vagaoReboque { get; set; }
        public string balsaReboque { get; set; }
        public decimal? qtdeVolTransportados { get; set; }
        public string especieVolTransportados { get; set; }
        public string marcaVolTransportados { get; set; }
        public string numeracaoVolTransportados { get; set; }
        public decimal? pesoLiquido { get; set; }
        public decimal? pesoBruto { get; set; }
        public string numeroLacres { get; set; }
    }

}