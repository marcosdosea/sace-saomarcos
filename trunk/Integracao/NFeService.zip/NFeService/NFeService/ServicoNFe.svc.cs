﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using NFeService.Model;
using NHibernate;
using NFeService.NHibernate;
using NFeService.Util;

namespace NFeService
{
    public class ServicoNFe : INFe
    {
        public ServicoNFe()
        {
            NHibernateHelper.getItemConfiguracao().OpenSession();
        }

        public IList<NFeCabecalhoDTO> selectNFeCabecalho(NFeCabecalhoDTO nfeCabecalho)
        {
            try
            {
                IList<NFeCabecalhoDTO> resultado = null;
                using (ISession session = NHibernateHelper.getItemConfiguracao().OpenSession())
                {
                    NHibernateDAL<NFeCabecalhoDTO> nfeDAL = new NHibernateDAL<NFeCabecalhoDTO>(session);
                    resultado = nfeDAL.select(nfeCabecalho);
                }
                return resultado;
            }
            catch (Exception ex)
            {
                throw new FaultException(ex.Message);
            }
        }

        public NFeCabecalhoDTO selectNFeCabecalhoId(int id)
        {
            try
            {
                NFeCabecalhoDTO resultado = null;
                using (ISession session = NHibernateHelper.getItemConfiguracao().OpenSession())
                {
                    NHibernateDAL<NFeCabecalhoDTO> nfeDAL = new NHibernateDAL<NFeCabecalhoDTO>(session);
                    resultado = nfeDAL.selectId<NFeCabecalhoDTO>(id);

                    NHibernateDAL<NFeDestinatarioDTO> nfeDest = new NHibernateDAL<NFeDestinatarioDTO>(session);
                    IList<NFeDestinatarioDTO> listDest = nfeDest.select<NFeDestinatarioDTO>(new NFeDestinatarioDTO { idNFeCabecalho = id });
                    if (listDest.Count > 0) 
                    {
                        resultado.destinatario = listDest.First();
                    }

                    NHibernateDAL<NFeEmitenteDTO> nfeEmit = new NHibernateDAL<NFeEmitenteDTO>(session);
                    IList<NFeEmitenteDTO> listEmit = nfeDest.select<NFeEmitenteDTO>(new NFeEmitenteDTO { idNFeCabecalho = id });
                    if (listEmit.Count > 0)
                    {
                        resultado.emitente = listEmit.First();
                    }

                    NHibernateDAL<NFeLocalEntregaDTO> nfeLE = new NHibernateDAL<NFeLocalEntregaDTO>(session);
                    IList<NFeLocalEntregaDTO> listLE = nfeLE.select<NFeLocalEntregaDTO>(new NFeLocalEntregaDTO { idNFeCabecalho = id });
                    if (listLE.Count > 0)
                    {
                        resultado.localEntrega = listLE.First();
                    }

                    NHibernateDAL<NFeLocalRetiradaDTO> nfeLR = new NHibernateDAL<NFeLocalRetiradaDTO>(session);
                    IList<NFeLocalRetiradaDTO> listLR = nfeLR.select<NFeLocalRetiradaDTO>(new NFeLocalRetiradaDTO { idNFeCabecalho = id });
                    if (listLR.Count > 0)
                    {
                        resultado.localRetirada= listLR.First();
                    }

                    NHibernateDAL<NFeTransporteDTO> nfeTransporte = new NHibernateDAL<NFeTransporteDTO>(session);
                    IList<NFeTransporteDTO> listTransp = nfeTransporte.select<NFeTransporteDTO>(new NFeTransporteDTO { idNFeCabecalho = id });
                    if (listTransp.Count > 0)
                    {
                        resultado.transporte = listTransp.First();
                    }

                    NHibernateDAL<NFeFaturaDTO> nfeFatura = new NHibernateDAL<NFeFaturaDTO>(session);
                    IList<NFeFaturaDTO> listFat = nfeFatura.select<NFeFaturaDTO>(new NFeFaturaDTO { idNFeCabecalho = id });
                    if (listFat.Count > 0)
                    {
                        resultado.fatura = listFat.First();

                        NHibernateDAL<NFeDuplicataDTO> nfeDupl = new NHibernateDAL<NFeDuplicataDTO>(session);
                        resultado.fatura.listaDuplicata = nfeDupl.select<NFeDuplicataDTO>(new NFeDuplicataDTO { idNFeFatura = resultado.fatura.id });
                    }

                    NHibernateDAL<NFeCupomFiscalDTO> nfeCF = new NHibernateDAL<NFeCupomFiscalDTO>(session);
                    resultado.listaCupomFiscal = nfeCF.select<NFeCupomFiscalDTO>(new NFeCupomFiscalDTO { idNFeCabecalho = id });

                    NHibernateDAL<NFeDetalheDTO> nfeDetDAL = new NHibernateDAL<NFeDetalheDTO>(session);
                    resultado.listaDetalhe = nfeDetDAL.select<NFeDetalheDTO>(new NFeDetalheDTO { idNFeCabecalho = id });
                }

                return resultado;
            }
            catch (Exception ex)
            {
                throw new FaultException(ex.Message);
            }
        }

        public IList<ProdutoDTO> selectProduto(ProdutoDTO produto)
        {
            try
            {
                IList<ProdutoDTO> resultado = null;
                using (ISession session = NHibernateHelper.getItemConfiguracao().OpenSession())
                {
                    NHibernateDAL<ProdutoDTO> produtoDAL = new NHibernateDAL<ProdutoDTO>(session);
                    resultado = produtoDAL.select(produto);
                }
                return resultado;
            }
            catch (Exception ex)
            {
                throw new FaultException(ex.Message);
            }
        }

        public int salvarNFeCabecalho(NFeCabecalhoDTO nfeCabecalho)
        {
            try
            {
                int resultado = -1;
                using (ISession session = NHibernateHelper.getItemConfiguracao().OpenSession())
                {
                    NHibernateDAL<NFeCabecalhoDTO> nfeDAL = new NHibernateDAL<NFeCabecalhoDTO>(session);

                    nfeCabecalho.chaveAcesso = nfeCabecalho.emitente.codigoMunicipio.ToString().Substring(0, 2) +
                    ((DateTime)nfeCabecalho.dataEmissao).ToString("yy") +
                    ((DateTime)nfeCabecalho.dataEmissao).ToString("MM") +
                    nfeCabecalho.emitente.cpfCnpj +
                    (int.Parse(nfeCabecalho.codigoModelo)).ToString("00") +
                    (int.Parse(nfeCabecalho.serie)).ToString("000") +
                    (int.Parse(nfeCabecalho.numero)).ToString("000000000") +
                    nfeCabecalho.finalidadeEmissao +
                    (int.Parse(nfeCabecalho.numero)).ToString("00000000");
                    nfeCabecalho.digitoChaveAcesso = Biblioteca.DigitoModulo11(nfeCabecalho.chaveAcesso);

                    nfeCabecalho.numero = (int.Parse(nfeCabecalho.numero)).ToString("000000000");
                    nfeCabecalho.codigoNumerico = (int.Parse(nfeCabecalho.numero)).ToString("00000000");

                    //Ambiente, 2 - homologacao
                    nfeCabecalho.ambiente = "2";

                    nfeDAL.saveOrUpdate(nfeCabecalho);

                    if (nfeCabecalho.destinatario != null)
                    {
                        NHibernateDAL<NFeDestinatarioDTO> nfeDest = new NHibernateDAL<NFeDestinatarioDTO>(session);
                        nfeCabecalho.destinatario.idNFeCabecalho = nfeCabecalho.id;
                        nfeDest.saveOrUpdate(nfeCabecalho.destinatario);
                    }

                    if (nfeCabecalho.emitente != null)
                    {
                        NHibernateDAL<NFeEmitenteDTO> nfeEmit = new NHibernateDAL<NFeEmitenteDTO>(session);
                        nfeCabecalho.emitente.idNFeCabecalho = nfeCabecalho.id;
                        nfeEmit.saveOrUpdate(nfeCabecalho.emitente);
                    }

                    if (nfeCabecalho.fatura != null)
                    {
                        NHibernateDAL<NFeFaturaDTO> nfeFatura = new NHibernateDAL<NFeFaturaDTO>(session);
                        nfeCabecalho.fatura.idNFeCabecalho = nfeCabecalho.id;
                        nfeFatura.saveOrUpdate(nfeCabecalho.fatura);

                        NHibernateDAL<NFeDuplicataDTO> nfeDupl = new NHibernateDAL<NFeDuplicataDTO>(session);

                        IList<NFeDuplicataDTO> listaDupExistente = nfeDupl.select(new NFeDuplicataDTO { idNFeFatura = nfeCabecalho.fatura.id });
                        foreach (NFeDuplicataDTO dupli in listaDupExistente)
                        {
                            nfeDupl.delete(dupli);
                        }

                        if (nfeCabecalho.fatura.listaDuplicata.Count > 0)
                        {
                            IList<NFeDuplicataDTO> listaDupl = nfeCabecalho.fatura.listaDuplicata;
                            foreach (NFeDuplicataDTO dupl in listaDupl)
                            {
                                dupl.idNFeFatura = nfeCabecalho.fatura.id;
                                nfeDupl.saveOrUpdate((NFeDuplicataDTO)session.Merge(dupl));
                            }
                        }
                    }
                    if (nfeCabecalho.listaCupomFiscal.Count > 0)
                    {
                        NHibernateDAL<NFeCupomFiscalDTO> nfeCF = new NHibernateDAL<NFeCupomFiscalDTO>(session);

                        IList<NFeCupomFiscalDTO> listaCFExistente = nfeCF.select(new NFeCupomFiscalDTO { idNFeCabecalho = nfeCabecalho.id });
                        foreach (NFeCupomFiscalDTO cf in listaCFExistente)
                        {
                            nfeCF.delete(cf);
                        }

                        IList<NFeCupomFiscalDTO> listaCupom = nfeCabecalho.listaCupomFiscal;
                        foreach (NFeCupomFiscalDTO nfeCupom in listaCupom)
                        {
                            nfeCupom.idNFeCabecalho = nfeCabecalho.id;
                            nfeCF.saveOrUpdate((NFeCupomFiscalDTO)session.Merge(nfeCupom));
                        }
                    }

                    if (nfeCabecalho.listaDetalhe.Count > 0)
                    {
                        NHibernateDAL<NFeDetalheDTO> nfeDetDAL = new NHibernateDAL<NFeDetalheDTO>(session);

                        IList<NFeDetalheDTO> listaDetExistente = nfeDetDAL.select(new NFeDetalheDTO { idNFeCabecalho = nfeCabecalho.id });
                        foreach (NFeDetalheDTO det in listaDetExistente)
                        {
                            nfeDetDAL.delete(det);
                        }

                        IList<NFeDetalheDTO> listaDetalhe = nfeCabecalho.listaDetalhe;
                        foreach (NFeDetalheDTO nfeDet in listaDetalhe)
                        {
                            nfeDet.idNFeCabecalho = nfeCabecalho.id;
                            nfeDetDAL.saveOrUpdate((NFeDetalheDTO)session.Merge(nfeDet));
                        }
                    }

                    if (nfeCabecalho.localEntrega != null)
                    {
                        NHibernateDAL<NFeLocalEntregaDTO> nfeLE = new NHibernateDAL<NFeLocalEntregaDTO>(session);
                        nfeCabecalho.localEntrega.idNFeCabecalho = nfeCabecalho.id;
                        nfeLE.saveOrUpdate(nfeCabecalho.localEntrega);
                    }

                    if (nfeCabecalho.localRetirada != null)
                    {
                        NHibernateDAL<NFeLocalRetiradaDTO> nfeLR = new NHibernateDAL<NFeLocalRetiradaDTO>(session);
                        nfeCabecalho.localRetirada.idNFeCabecalho = nfeCabecalho.id;
                        nfeLR.saveOrUpdate(nfeCabecalho.localRetirada);
                    }

                    if (nfeCabecalho.transporte != null)
                    {
                        NHibernateDAL<NFeTransporteDTO> nfeTransporte = new NHibernateDAL<NFeTransporteDTO>(session);
                        nfeCabecalho.transporte.idNFeCabecalho = nfeCabecalho.id;
                        nfeTransporte.saveOrUpdate(nfeCabecalho.transporte);
                    }



                    session.Flush();
                }

                return resultado;
            }
            catch (Exception ex)
            {
                throw new FaultException(ex.Message);
            }
        }

        public EmpresaDTO selectEmpresaId(int id)
        {
            try
            {
                EmpresaDTO resultado = null;
                using (ISession session = NHibernateHelper.getItemConfiguracao().OpenSession())
                {
                    NHibernateDAL<EmpresaDTO> empresaDAL = new NHibernateDAL<EmpresaDTO>(session);
                    resultado = empresaDAL.selectId<EmpresaDTO>(id);

                    NHibernateDAL<EnderecoDTO> endDAL = new NHibernateDAL<EnderecoDTO>(session);
                    IList<EnderecoDTO> listaEnd = endDAL.select(new EnderecoDTO { idEmpresa = resultado.id });
                    if (listaEnd.Count > 0)
                        resultado.endereco = listaEnd.First();

                }
                return resultado;
            }
            catch (Exception ex)
            {
                throw new FaultException(ex.Message);
            }
        }
    }
}
