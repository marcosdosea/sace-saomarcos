﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using NFeService.Model;

namespace NFeService
{
    [ServiceContract]
    public interface INFe
    {
        [OperationContract]
        EmpresaDTO selectEmpresaId(int id);

        [OperationContract]
        IList<NFeCabecalhoDTO> selectNFeCabecalho(NFeCabecalhoDTO nfeCabecalho);

        [OperationContract]
        int salvarNFeCabecalho(NFeCabecalhoDTO nfeCabecalho);

        [OperationContract]
        NFeCabecalhoDTO selectNFeCabecalhoId(int id);

        [OperationContract]
        IList<ProdutoDTO> selectProduto(ProdutoDTO produto);
    }


}
